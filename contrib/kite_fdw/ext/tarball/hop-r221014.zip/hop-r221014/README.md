# hop
hash operations
