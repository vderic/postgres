#ifndef HJREC_H
#define HJREC_H

#include "../src/hashjoin.h"
#include "harness.h"

static uint64_t hashi(int i) { return hash(&i, sizeof(i)); }

// Tuples from the left side of the join
typedef struct left_t left_t;
struct left_t {
  int side;
  int key;
  int value;
};
static int is_left(const void *p) { return ((left_t *)p)->side == 'L'; }

// Tuples from the right side of the join
typedef struct right_t right_t;
struct right_t {
  int side;
  char key[100];
  int value;
};
static int is_right(const void *p) { return ((right_t *)p)->side == 'R'; }

// Get the next left tuple
// even numbers [2,4,6,...,200]
static int get_left(left_t *tp) {
  // left table has tuples with keys from 1..100
  static int serial = 0;
  if (serial >= 200) {
    return -1;
  }
  serial += 2;

  tp->side = 'L';
  tp->key = serial;
  tp->value = serial;

  return 0;
}

// Get the next right tuple
// serial [1..100]
static int get_right(right_t *tp) {
  static int serial = 0;
  if (serial >= 100) {
    return -1;
  }
  serial++;

  memset(tp, 0, sizeof(*tp)); // silent valgrind
  tp->side = 'R';
  sprintf(tp->key, "%d", serial);
  tp->value = serial;

  return 0;
}

int count_hit_both = 0;
int count_hit_right = 0;
int count_hit_left = 0;

static int match(void *context, const void *br, const void *pr) {
  (void)context;
  CHECK(!br || is_left(br));
  CHECK(!pr || is_right(pr));
  const left_t *LP = br;
  const right_t *RP = pr;

  if (!LP) {
    printf("hit (- - -) (%c %s %d)\n", RP->side, RP->key, RP->value);
    count_hit_right++;
  } else if (!RP) {
    printf("hit (%c %d %d) (- - -)\n", LP->side, LP->key, LP->value);
    count_hit_left++;
  } else {
    printf("hit (%c %d %d) (%c %s %d)\n", LP->side, LP->key, LP->value,
           RP->side, RP->key, RP->value);
    count_hit_both++;
  }
  return 0;
}

static int keyeq(void *context, const void *br, const void *pr) {
  (void)context;
  CHECK(is_left(br));
  CHECK(is_right(pr));
  const left_t *LP = br;
  const right_t *RP = pr;
  return LP->key == atoi(RP->key);
}

static int reclen(const void *rec) {
  if (is_left(rec)) {
    return sizeof(left_t);
  }
  if (is_right(rec)) {
    return sizeof(right_t);
  }
  CHECK(0);
  return 0;
}

#endif /* HJREC_H */
