// INNER JOIN
#include "hjrec.h"

hj_t *hj = 0;

// Scan left side and feed to hj
static void build() {

  // For each tuple from LEFT side
  for (;;) {
    left_t tup;
    if (get_left(&tup)) {
      break;
    }
    uint64_t hval = hashi(tup.key);

    CHECK(0 == hj_build(hj, hval, &tup));
  }
}

static void probe() {

  // For each tuple from RIGHT side
  for (;;) {
    right_t tup;
    if (get_right(&tup)) {
      break;
    }
    uint64_t hval = hashi(atoi(tup.key));

    CHECK(0 == hj_probe(hj, hval, &tup, match));
  }

  CHECK(0 == hj_probe_spilled(hj, match));
}

int main() {
  char *context = 0;
  printf("\nINNER JOIN\n\n");
  hj = hj_start(context, HJ_INNER, 100, ".", reclen, keyeq);
  CHECK(hj);
  build();
  probe();
  hj_release(hj);

  printf("hit_both = %d\n", count_hit_both);
  printf("hit_left = %d\n", count_hit_left);
  printf("hit_right = %d\n", count_hit_right);
  CHECK(50 == count_hit_both);
  CHECK(0 == count_hit_left);
  CHECK(0 == count_hit_right);
  printf("\n");

  return 0;
}
