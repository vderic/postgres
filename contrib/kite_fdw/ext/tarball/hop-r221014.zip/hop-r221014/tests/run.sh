echo Make ...
(cd ..; make) > /dev/null || { echo "Make failed!"; exit 1; }

mkdir -p out
for i in ch{1..1} sp{1..1} hj{1..5} hagg{1..5}; do
    F=$i
    if [ -f $F ]; then
	echo $F
	./$F > out/$F.out || { echo "FAILED!"; exit 1; }
	diff out/$F.out good/$F.out || { echo "FAILED!"; exit 1; }
    fi
done
