#include "../src/hashagg.h"
#include "harness.h"

/*
   Do agg count, sum, avg on a table like this:

   A    B
   1    1
   2    2
   3    3
   4	4
   ...
   1000 1000


   select count(*), sum(A), sum(B) from T;
*/

// Tuples
typedef struct tuple_t tuple_t;
struct tuple_t {
  int A;
  int B;
};

// Generate tuples
static int get_tuple(tuple_t *tp) {
  static int serial = 0;
  if (serial >= 1000) {
    return -1;
  }
  serial++;

  tp->A = serial;
  tp->B = serial;
  return 0;
}

static int keyeq(void *context, const void *rec1, const void *rec2) {
  (void)context;
  (void)rec1;
  (void)rec2;
  return 1;
}

// Our agg will store count and sum
typedef struct aggdata_t aggdata_t;
struct aggdata_t {
  int count;
  int sumA;
  int sumB;
};

// On init: alloc memory for aggdata associated with rec and initialize with
// count and sum.
static void *init(void *context, const void *rec) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = malloc(sizeof(*dp));
  if (dp) {
    dp->count = 1;
    dp->sumA = tp->A;
    dp->sumB = tp->B;
  }
  return dp;
}

// On transition: update count and sum of aggdata related to rec
static void *trans(void *context, const void *rec, void *data) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = data;
  dp->count++;
  dp->sumA += tp->A;
  dp->sumB += tp->B;
  return dp;
}

char *output[1000] = {0};
int line = 0;

// On finalize: save results and free aggdata allocated
static int finalize(void *context, const void *rec, void *data) {
  (void)context;
  (void)rec;
  aggdata_t *dp = data;
  char *s = malloc(100);
  CHECK(s);

  sprintf(s, "%04d\t%d\t%d", dp->count, dp->sumA, dp->sumB);

  CHECK(line < 1000);
  output[line++] = s;

  free(data);
  return 0;
}

static int mycmp(const void *a, const void *b) {
  char **x = (char **)a;
  char **y = (char **)b;
  return strcmp(*x, *y);
}

int main() {
  // Create a hashagg
  hagg_t *agg = hagg_start(0, 100, ".", keyeq, init, trans);

  // Feed the hashagg with tuples
  while (1) {
    tuple_t tup;
    if (0 != get_tuple(&tup)) {
      break;
    }
    uint64_t hval = 0;
    CHECK(0 == hagg_feed(agg, hval, &tup, sizeof(tup)));
  }

  // Obtain the #batches
  int top = hagg_batch_max(agg);
  printf("#batch = %d\n", top);

  // Finalize each batch
  for (int id = 0; id < top; id++) {
    CHECK(0 == hagg_finalize_batch(agg, id, finalize));
  }

  // Done!
  hagg_release(agg);

  // Print (sorted) results.
  printf("\ncount\tsum(A)\tsum(B)\n");
  qsort(output, line, sizeof(char *), mycmp);
  for (int i = 0; i < line; i++) {
    printf("%s\n", output[i]);
    free(output[i]);
  }
  return 0;
}
