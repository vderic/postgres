#ifndef HARNESS_H
#define HARNESS_H

#include "../src/komihash.h"
#include <stdio.h>
#include <stdlib.h>

#define xstr(s) STRINGIFY(s)
#define STRINGIFY(s) #s

static inline void fatal(const char *cond, int line) {
  fprintf(stderr, "Assertion (%s) failed at line %d\n", cond, line);
  abort();
}

static inline uint64_t hash(const void *ptr, int len) {
  return komihash(ptr, len, 0);
}

// clang-format off
#define CHECK(x)    if (x) ; else fatal(STRINGIFY(x), __LINE__)
// clang-format on

#endif
