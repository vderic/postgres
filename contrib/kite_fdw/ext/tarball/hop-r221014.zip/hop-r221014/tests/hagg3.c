#define _XOPEN_SOURCE 500
#include "../src/hashagg.h"
#include "harness.h"

/*
   Do agg concat

   id name value
   1  a    a
   2  b    b
   3  c    c
   ...
   1000 ...


   select name, concat(value) from T group by name
*/

// Tuples
typedef struct tuple_t tuple_t;
struct tuple_t {
  int id;
  char name[2];
  char value[2];
};

// Hash tuple using the name field (the group by column)
static uint64_t hashtup(tuple_t *tp) {
  return hash(tp->name, strlen(tp->name));
}

// Generate tuples for insertion into hagg.
static int get_tuple(tuple_t *tp) {
  static int serial = 0;
  if (serial >= 1000) {
    return -1;
  }
  serial++;

  tp->id = serial;
  tp->name[0] = 'a' + ((serial - 1) % 26);
  tp->name[1] = 0;
  strcpy(tp->value, tp->name);
  return 0;
}

// Two tuples are considered equal if t1->name == t2->name.
static int keyeq(void *context, const void *rec1, const void *rec2) {
  (void)context;
  const tuple_t *t1 = rec1;
  const tuple_t *t2 = rec2;
  return 0 == strcmp(t1->name, t2->name);
}

typedef struct aggdata_t aggdata_t;
struct aggdata_t {
  char *str;
};

// On init: alloc a data section to store a string, and init the string with the
// 'value' of the rec.
static void *init(void *context, const void *rec) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = malloc(sizeof(*dp));
  CHECK(dp);
  dp->str = strdup(tp->value);
  CHECK(dp->str);
  return dp;
}

// On trans: extend the size of the string in data, and concat 'value' to it.
static void *trans(void *context, const void *rec, void *data) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = data;
  char *str = realloc(dp->str, strlen(dp->str) + strlen(tp->value) + 1);
  CHECK(str);
  dp->str = strcat(str, tp->value);
  return dp;
}

char *output[1000] = {0};
int line = 0;

// On finalize: save the output, and clean up memory used to accumulate values
// for this rec.
static int finalize(void *context, const void *rec, void *data) {
  (void)context;
  const tuple_t *tp = rec;
  aggdata_t *dp = data;

  char *s = malloc(100);
  CHECK(s);
  snprintf(s, 100, "%s\t%s", tp->name, dp->str);

  CHECK(line < 1000);
  output[line++] = s;

  free(dp->str);
  free(dp);
  return 0;
}

static int mycmp(const void *a, const void *b) {
  char **x = (char **)a;
  char **y = (char **)b;
  return strcmp(*x, *y);
}

int main() {
  // Start an agg. Limit to 100-bytes available memory.
  hagg_t *agg = hagg_start(0, 100, ".", keyeq, init, trans);

  // Feed tuples to the agg
  while (1) {
    tuple_t tup;
    if (0 != get_tuple(&tup)) {
      break;
    }
    uint64_t hval = hashtup(&tup);
    CHECK(0 == hagg_feed(agg, hval, &tup, sizeof(tup)));
  }

  // Determine #batches
  int top = hagg_batch_max(agg);
  printf("#batch = %d\n", top);

  // Finalize each batch
  for (int id = 0; id < top; id++) {
    CHECK(0 == hagg_finalize_batch(agg, id, finalize));
  }

  // Done!
  hagg_release(agg);

  // Print the (sorted) results
  printf("\nname\tconcat(value)\n");
  qsort(output, line, sizeof(char *), mycmp);
  for (int i = 0; i < line; i++) {
    printf("%s\n", output[i]);
    free(output[i]);
  }
  return 0;
}
