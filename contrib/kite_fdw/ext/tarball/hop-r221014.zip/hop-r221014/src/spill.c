#define _POSIX_C_SOURCE 200809L
#define _GNU_SOURCE
#include "spill.h"
#include "../src/komihash.h"
#include "mbloom.h"
#include "spill_file.h"
#include "support.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static int local_random() {
  static uint64_t seed1 = 0;
  static uint64_t seed2 = 0;
  if (seed1 == 0) {
    seed1 = seed2 = getpid();
  }
  return komirand(&seed1, &seed2) & 0x7FFFFFFF;
}

static uint64_t next_serial() {
  static _Atomic uint64_t serial_gen = 0;
  if (serial_gen == 0) {
    serial_gen = local_random();
  }
  serial_gen++;
  return serial_gen;
}

// always return -1
static int reterr(int dummy) {
  (void)dummy;
  return -1;
}

#define perr(fmt, ...) reterr(snprintf(errmsg, errlen, fmt, ##__VA_ARGS__))

// For a value N, there are 2^N buckets, each with two
// spill files for build and probe.
typedef struct spill_bucket_t bucket_t;
struct spill_bucket_t {
  int N;
  int id;          // range [0..(2^N)-1]
  int nbyte_inbuf; // #bytes belonging to this bucket in spill_t::buf
  int nrow_inbuf;  // #rows belonging to this bucket in spill_t::buf
  char *path;
};

// Create a bucket
static bucket_t *bucket_new(int N, int id) {
  bucket_t *p = calloc(1, sizeof(*p));
  if (p) {
    p->N = N;
    p->id = id;
  }
  return p;
}

// Delete a bucket. Will drop the files.
static void bucket_drop(bucket_t *p) {
  if (p) {
    if (p->path) {
      unlink(p->path);
      free(p->path);
    }
    free(p);
  }
}

// Create the spill
spill_t *spill_create(const char *dir) {
  spill_t *sp = calloc(1, sizeof(spill_t));
  CHECKBAIL(sp);

  sp->serial = next_serial();
  sp->dir = strdup(dir);
  CHECKBAIL(sp->dir);

  sp->bucket = malloc(sizeof(*sp->bucket));
  CHECKBAIL(sp->bucket);

  sp->bucket[0] = bucket_new(0, 0);
  CHECKBAIL(sp->bucket[0]);

  return sp;

bail:
  spill_destroy(sp);
  return 0;
}

// Cleanup and delete the spill
void spill_destroy(spill_t *sp) {
  if (sp) {
    for (int i = 0, top = (1 << sp->N); i < top; i++) {
      bucket_drop(sp->bucket[i]);
    }
    free(sp->bucket);
    free(sp->buf.ptr);
    free((void *)sp->dir);
    free(sp->bloom);
    free(sp);
  }
}

// Double the buckets in a spill.
int spill_expand(spill_t *sp, char *errmsg, int errlen) {

  if (sp->buf.part != SPILL_BUILD) {
    return perr("%s", "spill is not in build phase");
  }

  // create the bloom filter on first call
  if (!sp->bloom) {
    sp->bloom = mbloom_create(1024 * 1024 * 8); // 1MB
    if (!sp->bloom) {
      return perr("%s", "out of memory");
    }
  }

  // expand spill
  int N = sp->N + 1;
  if (N > 10)
    return 0; /* no more than 1024 spill files */

  // expand the ptr array
  bucket_t **bucket = realloc(sp->bucket, (1 << N) * sizeof(*bucket));
  if (!bucket) {
    return perr("%s", "out of memory");
  }
  for (int i = (1 << (N - 1)), top = (1 << N); i < top; i++) {
    bucket[i] = 0;
  }
  sp->N = N;
  sp->bucket = bucket;

  // create the (new) buckets
  for (int i = (1 << (N - 1)), top = (1 << N); i < top; i++) {
    bucket[i] = bucket_new(N, i);
    if (!bucket[i]) {
      return perr("%s", "out of memory");
    }
  }

  // recompute for each bucket the #bytes in buf
  for (int i = 0, top = (1 << N); i < top; i++) {
    bucket[i]->nbyte_inbuf = 0;
    bucket[i]->nrow_inbuf = 0;
  }
  assert(sp->buf.bot == 0);
  char *p = sp->buf.ptr;
  char *q = sp->buf.ptr + sp->buf.top;
  while (p < q) {
    spill_rec_t rec;
    memcpy(&rec, p, sizeof(rec));
    int recsz = rec_size(&rec);
    int id = spill_id(sp, rec.hval);
    bucket[id]->nbyte_inbuf += recsz;
    bucket[id]->nrow_inbuf += 1;
    p += recsz;
  }
  assert(p == q);

  // expand the buf to minimum of 16KB * #buckets
  int minsz = 16 * 1024 * (1 << N);
  if (sp->buf.max < minsz) {
    int newmax = minsz;
    char *tmp = realloc(sp->buf.ptr, newmax);
    if (!tmp) {
      return perr("%s", "out of memory");
    }
    sp->buf.ptr = tmp;
    sp->buf.max = newmax;
  }

  return 0;
}

// Find the id that has the most #bytes in buf
static int select_heaviest_bucket(spill_t *sp) {
  int id = -1;
  int biggestchunk = 0;
  for (int i = 0, top = (1 << sp->N); i < top; i++) {
    int nb = sp->bucket[i]->nbyte_inbuf;
    if (nb >= biggestchunk) {
      biggestchunk = nb;
      id = i;
    }
  }
  return id;
}

// Squeeze out records with 'id'
static void squeeze_buffer(spill_t *sp, int id) {
  assert(sp->buf.bot == 0);
  char *p = sp->buf.ptr;
  char *q = sp->buf.ptr + sp->buf.top;
  char *s = p;
  while (p < q) {
    spill_rec_t rec;
    memcpy(&rec, p, sizeof(rec));
    int recsz = rec_size(&rec);
    if (spill_id(sp, rec.hval) != id) {
      // keep this record
      memmove(s, p, recsz);
      s += recsz;
    }
    p += recsz;
  }
  assert(p == q);

  // update the top offset
  sp->buf.top = s - sp->buf.ptr;

  // update the buffer usage for bucket[id]
  sp->bucket[id]->nbyte_inbuf = 0;
  sp->bucket[id]->nrow_inbuf = 0;
}

// Get a random file name in the spill dir with a VERY low probability
// that the file exists currently
static char *rand_path(spill_t *sp) {
  char *path = 0;
  if (-1 == asprintf(&path, "%s/spill_%d_%x", sp->dir, (int)sp->serial,
                     local_random())) {
    return 0;
  }
  return path;
}

// Create a spill file and return the path
static char *create_file(spill_t *sp, char *errmsg, int errlen) {
  for (;;) {
    /* get a path name and try to create the file. If we failed because the file
     * already exists, retry! */
    char *path = rand_path(sp);
    if (!path) {
      perr("%s", "out of memory");
      return 0;
    }

    int fd = open(path, O_CREAT | O_EXCL | O_WRONLY, 0600);
    if (fd < 0) {
      perr("open(%s): %s", path, strerror(errno));
      free(path);
      if (errno == EEXIST) {
        // collision! this is VERY UNLIKELY.
        continue; // try again
      }
      return 0;
    }

    // success
    close(fd);
    return path;
  }
}

// Flush some bytes in the spill buffer to disk
static int flush_some(spill_t *sp, char *errmsg, int errlen) {
  spill_append_t *fp = 0;

  // which bucket has the max #bytes in buffer?
  int id = select_heaviest_bucket(sp);
  if (!(0 <= id && id < (1 << sp->N))) {
    perr("%s", "internal error");
    goto bail;
  }

  spill_bucket_t *bucket = sp->bucket[id];
  if (!bucket->path) {
    bucket->path = create_file(sp, errmsg, errlen);
    if (!bucket->path) {
      goto bail;
    }
  }

  // Open the file for append
  if (sp->buf.part == SPILL_BUILD) {
    fp = spill_append_build(bucket->path, errmsg, errlen);
  } else {
    fp = spill_append_probe(bucket->path, errmsg, errlen);
  }
  CHECKBAIL(fp);

  // Write records destined this file
  char *p = sp->buf.ptr;
  char *q = sp->buf.ptr + sp->buf.top;
  while (p < q) {
    spill_rec_t *rec = (spill_rec_t *)p;
    int recsz = rec_size(rec);
    if (spill_id(sp, rec->hval) == id) {
      CHECKBAIL(0 == spill_append(fp, rec, errmsg, errlen));
    }
    p += recsz;
  }
  assert(p == q);

  // Delete bytes written to the file. This will update sp->buf.top.
  squeeze_buffer(sp, id);

  return spill_append_close(fp, errmsg, errlen);

bail:
  spill_append_close(fp, errmsg, errlen);
  return -1;
}

static int ensure_buf_avail(spill_t *sp, int need, char *errmsg, int errlen) {
  // Keep flushing until there is enough space to fit need or the buffer is
  // empty
  int avail = sp->buf.max - sp->buf.top;
  while (avail < need && sp->buf.top != 0) {
    // make some space
    CHECK(0 == flush_some(sp, errmsg, errlen));
    avail = sp->buf.max - sp->buf.top;
  }

  // Still deficient?
  if (avail < need) {
    // expand the buffer. minimum 64KB or as big as need.
    int newmax = (need < 64 * 1024 ? 64 * 1024 : need);
    char *tmp = malloc(newmax);
    if (!tmp) {
      return perr("spill.ensure_buf: out of memory");
    }
    free(sp->buf.ptr);
    sp->buf.ptr = tmp;
    sp->buf.max = newmax;
    avail = sp->buf.max - sp->buf.top;
  }
  if (avail < need) {
    return perr("spill.ensure_buf: record is too big for spill");
  }
  return 0;
}

// Add a record to the corresponding spill file
int spill_add(spill_t *sp, spill_part_t part, uint64_t hval, const void *ptr,
              int len, char *errmsg, int errlen) {
  // records in sp->buf belongs to different part?
  if (part != sp->buf.part) {
    CHECK(0 == spill_flush(sp, errmsg, errlen)); // flush them
    sp->buf.part = part;                         // switch part
  }

  // which bucket?
  int id = spill_id(sp, hval);

  // add to bloom filter
  if (part == SPILL_BUILD) {
    mbloom_add(sp->bloom, hval);
  }

  // set up the header and compute record size
  spill_rec_t rec;
  rec.hval = hval;
  rec.len = len;
  int recsz = rec_size(&rec);

  // make sure we have enough space in buffer
  int avail = sp->buf.max - sp->buf.top;
  if (avail < recsz) {
    CHECK(0 == ensure_buf_avail(sp, recsz, errmsg, errlen));
    avail = sp->buf.max - sp->buf.top;
  }
  assert(avail >= recsz);

  // serialize the record into buffer
  spill_rec_t *p = (spill_rec_t *)&sp->buf.ptr[sp->buf.top];
  memcpy(p, &rec, sizeof(rec));
  memcpy(p->raw, ptr, len);
  sp->buf.top += recsz;

  // accounting
  sp->bucket[id]->nbyte_inbuf += recsz;
  sp->bucket[id]->nrow_inbuf += 1;
  sp->nrow += 1;
  sp->nbyte += recsz;

  return 0;
}

// Flush all records in spill buffer
int spill_flush(spill_t *sp, char *errmsg, int errlen) {
  // flush some bytes in the buffer until it is empty
  while (sp->buf.top) {
    CHECK(0 == flush_some(sp, errmsg, errlen));
  }
  return 0;
}

const char *spill_path(spill_t *sp, int id) {
  return (0 <= id && id < (1 << sp->N)) ? sp->bucket[id]->path : 0;
}
