#ifndef HASHAGG_H
#define HASHAGG_H

#include <stdint.h>

typedef struct hagg_t hagg_t;

// Check if two records fed to hagg are equal
typedef int hagg_keyeq_t(void *context, const void *rec1, const void *rec2);

// Initialize a new agg entry. Returns a pointer to be associated with rec.
// This probably involves a malloc() call to create struct associated with rec.
typedef void *hagg_initfn_t(void *context, const void *rec);

// Transition function. Given (rec, ptr), return same or different
// pointer to be associated with rec.
// This probably involves realloc(ptr) if the associated struct changes size.
typedef void *hagg_transfn_t(void *context, const void *rec, void *ptr);

// Finalize function. Take (rec, ptr) and do something with it.
// This probably involves free(ptr).
typedef int hagg_finfn_t(void *context, const void *rec, void *ptr);

/**
 *  Start a hashagg. Returns NULL if out-of-memory.
 */
extern hagg_t *hagg_start(void *context, int64_t memlimit, const char *spilldir,
                          hagg_keyeq_t *keyeq, hagg_initfn_t *init,
                          hagg_transfn_t *trans);

/**
 * Feed a record to the agg. Hagg will make a copy of rec[len]
 * internally. The init and trans functions will be invoked on rec[]
 * if it fits into the htab. Otherwise, rec[] will be spilled. Returns
 * 0 on success, -1 otherwise.
 */
extern int hagg_feed(hagg_t *agg, uint64_t hval, const void *rec, int len);

/**
 * Return the number of batches accumulated in the hagg.
 * Batch 0 is the current in-memory htab.
 * Batch 1 is spill #0.
 * Batch 2 is spill #1, etc.
 * Returns 0 on success, -1 otherwise.
 */
extern int hagg_batch_max(hagg_t *agg);

/**
 * Finalize the agg for a particular batch. The fin() will be invoked
 * with every distinct record in this batch. Returns 0 on success, -1
 * otherwise.
 */
extern int hagg_finalize_batch(hagg_t *agg, int batch, hagg_finfn_t *fin);

typedef struct hagg_iter_t hagg_iter_t;
struct hagg_iter_t {
  void *tab;
  int idx;
  void *atom;
};

extern int hagg_process_batch(hagg_t *agg, int batch, hagg_iter_t *iter);
extern int hagg_next(hagg_iter_t *iter, const void **ret_rec, void **ret_ptr);

/**
 * Release all resources.
 */
extern void hagg_release(hagg_t *agg);

/**
 * Retrieve the error message of the last failed function.
 */
extern const char *hagg_errmsg(hagg_t *agg);

#endif /* HASHAGG_H */
