#ifndef HASHJOIN_H
#define HASHJOIN_H

#include <stdint.h>

typedef struct hj_t hj_t;

// callback on hit/miss.
// br: build record
// pr: probe record
typedef int hj_matchfn_t(void *context, const void *br, const void *pr);

// check if keys from a build record and a probe record are equal
typedef int hj_keyeq_t(void *context, const void *br, const void *pr);

// given a build/probe record, returns the length of the record
typedef int hj_reclen_t(const void *rec);

typedef enum hj_type_t hj_type_t;
enum hj_type_t {
  HJ_INNER = 0,                 // matching pairs only
  HJ_LEFT = 1,                  // pairs + unmatched LHS tuples
  HJ_RIGHT = 2,                 // pairs + unmatched RHS tuples
  HJ_FULL = HJ_LEFT | HJ_RIGHT, // pairs + unmatched LHS + unmatched RHS
};

/**
 * Start a hashjoin. Returns NULL if out-of-memory.
 */
extern hj_t *hj_start(void *context, hj_type_t type, int64_t memlimit,
                      const char *spilldir, hj_reclen_t *reclen,
                      hj_keyeq_t *keyeq);

/**
 * Insert a record into the build side of the join. The build record is
 * either copied into memory managed by hj, or spilled to disk.
 * Returns 0 on success, -1 otherwise.
 */
extern int hj_build(hj_t *hj, uint64_t hval, const void *br);

/**
 * Probe the hashtable. The probe record may be spilled to disk. For each match,
 * call matchfn. Returns 0 on success, -1 otherwise.
 */
extern int hj_probe(hj_t *hj, uint64_t hval, const void *pr,
                    hj_matchfn_t matchfn);

/**
 * Join the records in each pair of build/probe spill files. For each match,
 * call matchfn. Returns 0 on success, -1 otherwise.
 */
extern int hj_probe_spilled(hj_t *hj, hj_matchfn_t matchfn);

/**
 * Release resources.
 */
extern void hj_release(hj_t *hj);

/**
 * Retrieve the error message of the last failed function.
 */
extern const char *hj_errmsg(hj_t *hj);

#endif /* HASHJOIN_H */
