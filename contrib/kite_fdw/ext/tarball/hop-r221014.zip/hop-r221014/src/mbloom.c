#include "mbloom.h"
#include <stdlib.h>

static uint32_t nextpow2(uint32_t v) {
  v--;
  v |= v >> 1;
  v |= v >> 2;
  v |= v >> 4;
  v |= v >> 8;
  v |= v >> 16;
  v++;
  return v;
}

mbloom_t *mbloom_create(int nbits) {
  nbits = (nbits + 7) & (-8);
  int nbyte = nbits / 8;
  if (nbyte < 0) {
    nbyte = 1;
  }
  nbyte = nextpow2(nbyte);
  mbloom_t *ret = 0;
  ret = calloc(1, (int)(intptr_t)&ret->map[nbyte]);
  if (ret) {
    ret->nbyte = nbyte;
    ret->mask = ((uint64_t)nbyte) * 8 - 1;
  }
  return ret;
}
