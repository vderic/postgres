#include "arena.h"
#include "support.h"
#include <assert.h>
#include <stdlib.h>

typedef struct block_t block_t;
struct block_t {
  block_t *next;
  int top;
  char data[1024 * 32 - 16 - 4];
};

typedef struct chunk_t chunk_t;
struct chunk_t {
  chunk_t *next;
  char data[0];
};

#define THRESHOLD (1024 * 4)

typedef struct Arena_t Arena_t;
struct Arena_t {
  int64_t nbyte; // #bytes explicitly allocated by caller (must be first item in
                 // struct to overlap with arena_t)
  block_t *block; /* for strings smaller than THRESHOLD */
  chunk_t *chunk; /* for strings larger than THRESHOLD */
};

arena_t *arena_create() {
  Arena_t *p = calloc(1, sizeof(*p));
  CHECKP(p);
  return (arena_t *)p;
}

void arena_destroy(arena_t *arena) {
  if (arena) {
    arena_reset(arena);
    free(arena);
  }
}

void arena_reset(arena_t *arena) {
  Arena_t *ap = (Arena_t *)arena;
  for (block_t *blk = ap->block; blk;) {
    block_t *next = blk->next;
    free(blk);
    blk = next;
  }
  for (chunk_t *chk = ap->chunk; chk;) {
    chunk_t *next = chk->next;
    free(chk);
    chk = next;
  }
  memset(ap, 0, sizeof(*ap));
}

#define ALIGN4(x) (((x) + 3) & ~3)

void *arena_alloc(arena_t *arena, int nb) {
  CHECKP(nb >= 0);

  Arena_t *ap = (Arena_t *)arena;
  nb = ALIGN4(nb);

  if (nb <= THRESHOLD) {
    // small object. allocate in block.
    block_t *blk = ap->block;
    int avail = blk ? sizeof(blk->data) - blk->top : 0;
    if (avail < nb) {
      // cannot fit! make a new block.
      blk = malloc(sizeof(*blk));
      CHECKP(blk);
      blk->next = ap->block;
      blk->top = 0;
      ap->block = blk;

      avail = sizeof(blk->data) - blk->top;
      assert(avail >= nb);
    }

    // advance the end marker
    blk->top += nb;

    // return pointer to allocated mem
    ap->nbyte += nb;
    return blk->data + blk->top - nb;
  }

  // big object. allocate in chunk list.
  chunk_t *chk = malloc(sizeof(chunk_t) + nb);
  CHECKP(chk);
  chk->next = ap->chunk;
  ap->chunk = chk;

  // return pointer to allocated mem
  ap->nbyte += nb;
  return chk->data;
}
