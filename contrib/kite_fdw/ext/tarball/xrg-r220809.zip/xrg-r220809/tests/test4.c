#include "harness.h"
#include <stdio.h>
#include <stdlib.h>

// Test bloom filter
int main() {

#ifdef NDEBUG
  fprintf(stderr, "warning: running in NON-DEBUG...\n");
#endif

  xrg_bloom_t bloom;
  xrg_bloom_init(&bloom);
  char buf[1000];
  char *list[26];
  char *p = buf;

  for (int i = 0; i < 26; i++) {
    list[i] = p;
    for (int j = 0; j <= i; j++) {
      *p++ = 'A' + j;
    }
    *p++ = 0;
  }

  /*
  for (int i = 0; i < 26; i++) {
    printf("%s\n", list[i]);
  }
  */

  for (int i = 0; i < 26; i++) {
    xrg_bloom_add(&bloom, list[i], strlen(list[i]));
  }

  for (int i = 0; i < 26; i++) {
    CHECK(xrg_bloom_isset(&bloom, list[i], strlen(list[i])));
  }

  CHECK(!xrg_bloom_isset(&bloom, "random", strlen("random")));

  return 0;
}
