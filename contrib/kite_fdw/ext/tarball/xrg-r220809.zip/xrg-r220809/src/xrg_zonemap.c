#include "xrg_int.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

struct xrg_zonemap_t {
  int nrowgroup;
  int nfield;
  int fd;
  int64_t rowgroupsz; /* #bytes per row-group */
  xrg_zonerec_t rec;
};

static int check_magic(const xrg_zonerec_t *rec) {
  if (0 != memcmp(rec->magic, XRG_ZONEMAP_MAGIC, 8) ||
      0 != memcmp(rec->magic2, XRG_ZONEMAP_MAGIC, 8)) {
    return -1;
  }
  return 0;
}

xrg_zonerec_t *xrg_zonemap_read(xrg_zonemap_t *zmp, int32_t rgidx, int fieldidx,
                                char *errbuf, int errbuflen) {
  if (!(0 <= rgidx && rgidx < zmp->nrowgroup)) {
    snprintf(errbuf, errbuflen, "xrg_zonemap_read: bad rgidx param");
    return 0;
  }
  if (!(0 <= fieldidx && fieldidx < zmp->nfield)) {
    snprintf(errbuf, errbuflen, "xrg_zonemap_read: bad fieldidx param");
    return 0;
  }

  int64_t off = rgidx * zmp->rowgroupsz + fieldidx * sizeof(xrg_zonerec_t);
  if (xrg_readfully_at(zmp->fd, off, &zmp->rec, sizeof(zmp->rec), errbuf,
                       errbuflen)) {
    return 0;
  }
  if (check_magic(&zmp->rec)) {
    snprintf(errbuf, errbuflen, "xrg_zonemap_read: %s", "bad magic number");
    return 0;
  }

  return &zmp->rec;
}

xrg_zonemap_t *xrg_zonemap_open(const char *fname, char *errbuf,
                                int errbuflen) {
  xrg_zonemap_t *zmp = calloc(1, sizeof(xrg_zonemap_t));
  if (!zmp) {
    snprintf(errbuf, errbuflen, "xrg_map_open: %s", "out of memory");
    goto bail;
  }

  zmp->fd = open(fname, O_RDONLY, 0600);
  if (zmp->fd == -1) {
    snprintf(errbuf, errbuflen, "xrg_zonemap_open: %s", strerror(errno));
    goto bail;
  }

  int64_t fsize = xrg_filesize(zmp->fd, errbuf, errbuflen);
  if (fsize < 0) {
    goto bail;
  }

  xrg_zonerec_t rec;

  // check the first record
  if (xrg_readfully_at(zmp->fd, 0, &rec, sizeof(rec), errbuf, errbuflen)) {
    goto bail;
  }
  if (check_magic(&rec)) {
    snprintf(errbuf, errbuflen, "xrg_zonemap_open: %s",
             "invalid record in file");
    goto bail;
  }

  // obtain nfield from the first record and compute the #rowgroup
  zmp->nfield = rec.nfield;
  zmp->rowgroupsz = (int64_t)zmp->nfield * sizeof(xrg_zonerec_t);
  zmp->nrowgroup = fsize / zmp->rowgroupsz;
  if (fsize != zmp->nrowgroup * zmp->rowgroupsz) {
    snprintf(errbuf, errbuflen, "xrg_zonemap_open: %s", "file is incomplete");
    goto bail;
  }

  // check the last record
  if (xrg_readfully_at(zmp->fd, fsize - sizeof(rec), &rec, sizeof(rec), errbuf,
                       errbuflen)) {
    goto bail;
  }
  if (check_magic(&rec)) {
    snprintf(errbuf, errbuflen, "xrg_zonemap_open: %s",
             "invalid record in file");
    goto bail;
  }

  return zmp;

bail:
  xrg_zonemap_close(zmp);
  return 0;
}

void xrg_zonemap_close(xrg_zonemap_t *zmp) {
  if (zmp) {
    if (zmp->fd >= 0) {
      close(zmp->fd);
    }
    free(zmp);
  }
}