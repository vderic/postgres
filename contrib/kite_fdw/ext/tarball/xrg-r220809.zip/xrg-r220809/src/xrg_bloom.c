#include "xrg_int.h"

void xrg_bloom_init(xrg_bloom_t *bloom) { memset(bloom, 0, sizeof(*bloom)); }

void xrg_bloom_add(xrg_bloom_t *bloom, const void *data, int len) {
  const int nbits = 8 * sizeof(bloom->bmp);
  xrg_crc32c_t idx = xrg_crc32c_init(data, len) % nbits;
  bloom->bmp[idx / 8] |= (0x80 >> (idx % 8));
}

int xrg_bloom_isset(const xrg_bloom_t *bloom, const void *data, int len) {
  const int nbits = 8 * sizeof(bloom->bmp);
  xrg_crc32c_t idx = xrg_crc32c_init(data, len) % nbits;
  return (bloom->bmp[idx / 8] & (0x80 >> (idx % 8))) != 0;
}
