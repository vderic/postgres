#define _DEFAULT_SOURCE
#include "xrg.h"
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// clang-format off
#define CHECK(x)  if (x); else return -1
#define CHECKP(x) if (x); else return NULL
// clang-format on

static int scan_digits(const char *s, const char **endp) {
  const char *p = s;
  int64_t ret = 0;
  for (; isdigit(*p); p++) {
    ret = 10 * ret + (*p - '0');
    CHECK(ret == (int64_t)((int)ret));
  }
  *endp = p;
  return (p == s) ? -1 : ret;
}

// Parse YYYY/MM/DD
// Return #day since epoch (1970/01/01)
int xrg_date_parse(int32_t *ret, const char *str, const char **endp) {
  if (!str) {
    ret = 0;
    *endp = 0;
    return 0;
  }
  const char *p = str;

  // year
  int year = scan_digits(p, endp);
  p = *endp;
  CHECK(year >= 0);

  char sep = *p++;
  CHECK(sep == '/' || sep == '-');

  // mon
  int mon = scan_digits(p, endp);
  p = *endp;
  CHECK(1 <= mon && mon <= 12);
  CHECK(*p++ == sep);

  // day
  int day = scan_digits(p, endp);
  p = *endp;
  CHECK(1 <= day && day <= 31);

  // convert to seconds since epoch
  struct tm tm;
  memset(&tm, 0, sizeof(tm));
  tm.tm_year = year - 1900;
  tm.tm_mon = mon - 1;
  tm.tm_mday = day;

  time_t x = timegm(&tm);
  CHECK(x != -1);

  *ret = x / (24 * 3600);
  return 0;
}

// Convert date to YYYY/MM/DD.
// Return pointer to buf on success, NULL otherwise.
char *xrg_date_str(int32_t date, char *buf, int buflen) {
  if (buflen <= 0) {
    return 0;
  }
  time_t t = (time_t)date * 24 * 3600;
  struct tm tm;
  if (!gmtime_r(&t, &tm)) {
    return 0;
  }
  snprintf(buf, buflen, "%04d-%02d-%02d", tm.tm_year + 1900, tm.tm_mon + 1,
           tm.tm_mday);
  return buf;
}

// Parse HH:MM:SS[.xxxxxx]
// Return #usec since 00:00:00.
int xrg_time_parse(int64_t *ret, const char *str, const char **endp) {
  if (!str) {
    ret = 0;
    *endp = 0;
    return 0;
  }

  int hh, mm, ss;
  {
    int s0 = str[0];
    int s1 = str[1];
    int s3 = str[3];
    int s4 = str[4];
    int s6 = str[6];
    int s7 = str[7];

    CHECK(isdigit(s0) && isdigit(s1) && isdigit(s3) && isdigit(s4) &&
          isdigit(s6) && isdigit(s7));
    CHECK(':' == str[2] && ':' == str[5]);

    hh = (s0 - '0') * 10 + s1 - '0';
    mm = (s3 - '0') * 10 + s4 - '0';
    ss = (s6 - '0') * 10 + s7 - '0';
  }

  CHECK(0 <= hh && hh <= 23);
  CHECK(0 <= mm && mm <= 59);
  CHECK(0 <= ss && ss <= 59);

  const char *p = *endp = str + 8;
  *ret = (int64_t)1000000 * (hh * 3600 + mm * 60 + ss);
  if (*p == '.') {
    // up to usec resolution
    int64_t unit = 100000;
    for (p++; isdigit(*p); p++, unit /= 10) {
      *ret += unit * (*p - '0');
    }
  }
  *endp = p;
  return 0;
}

// Convert time to HH:MM:SS[.xxxx]
// Return pointer to buf on success, NULL otherwise.
char *xrg_time_str(int64_t t, char *buf, int buflen) {
  if (buflen <= 0 || t < 0) {
    return 0;
  }

  char frac[10];
  {
    int n = sprintf(frac, ".%06d", (int)(t % 1000000));
    // remove trailing 0s
    while ('0' == frac[--n]) {
      frac[n] = 0;
    }
  }

  t /= 1000000;
  int ss = t % 60;
  t /= 60;
  int mm = t % 60;
  t /= 60;
  CHECKP(0 <= t && t <= 23);
  int hh = t;

  if (frac[1]) {
    snprintf(buf, buflen, "%02d:%02d:%02d%s", hh, mm, ss, frac);
  } else {
    snprintf(buf, buflen, "%02d:%02d:%02d", hh, mm, ss);
  }
  return buf;
}

// Parse yyyy/mm/dd[T ]HH:MM:SS[.xxxxxx[{Z|[+-][xx[:xx]]}]]
// Return #usec since epoch (1970/01/01 00:00:00)
int xrg_timestamp_parse(int64_t *ret, const char *str, const char **endp) {
  if (!str) {
    ret = 0;
    *endp = 0;
    return 0;
  }

  // parse date
  const char *p = str;
  int32_t day = 0;
  CHECK(0 == xrg_date_parse(&day, p, endp));
  p = *endp;

  // parse time
  int64_t usec = 0;
  if (*p == ' ' || toupper(*p) == 'T') {
    p++;
    CHECK(0 == xrg_time_parse(&usec, p, endp));
    p = *endp;

    // parse timezone
    int sign = toupper(*p);
    if (sign == 'Z' || sign == '-' || sign == '+') {
      p++;

      int hh = 0;
      int mm = 0;
      if (sign != 'Z' && isdigit(p[0]) && isdigit(p[1])) {
        hh = (p[0] - '0') * 10 + (p[1] - '0');
        CHECK(0 <= hh && hh <= 23);
        p += 2;
        if (p[0] == ':' && isdigit(p[1]) && isdigit(p[2])) {
          mm = (p[1] - '0') * 10 + (p[2] - '0');
          CHECK(0 <= mm && mm <= 59);
          p += 3;
        }
      }

      int64_t adjust = (int64_t)(sign == '-' ? -1 : 1) *
                       ((hh * 60 * 60) + (mm * 60)) * 1000000;
      usec -= adjust;
      *endp = p;
    }
  }

  *ret = (int64_t)day * (24 * 60 * 60) * 1000000 + usec;
  return 0;
}

char *xrg_timestamp_str(int64_t ts, char *buf, int buflen) {
  static const int64_t usec_per_hour = (int64_t)3600 * 1000000;
  static const int64_t usec_per_day = 24 * usec_per_hour;

  if (buflen <= 0) {
    return 0;
  }

  int32_t date = ts / usec_per_day;
  int64_t time = ts % usec_per_day;
  if (time < 0) {
    // When timestamp is 1969-12-31 23:59:59, time is negative 1 sec.
    // Add 24hr to make it 23:59:59.
    time += usec_per_day;

    // Took 24 hrs from date to add to time. Adjust date.
    date--;
  }
  char *p = buf;
  char *q = buf + buflen;

  CHECKP(xrg_date_str(date, p, q - p));
  p += strlen(p);

  if (p + 1 < q) {
    *p++ = ' ';
    *p = 0;
    CHECKP(xrg_time_str(time, p, q - p));
  }
  return buf;
}

// Parse X year X month X day [time]
// Return an interval record
int xrg_interval_parse(xrg_interval_t *ret, const char *str,
                       const char **endp) {
  memset(ret, 0, sizeof(*ret));
  if (!str) {
    *endp = 0;
    return 0;
  }

  int64_t mon = 0;
  int64_t day = 0;
  int64_t usec = 0;

  const char *p = str;
  const char *part = strstr(p, "year");
  if (part) {
    for (; isspace(*p); p++)
      ;
    errno = 0;
    int64_t val = strtoll(p, (char **)endp, 10);
    CHECK(!errno);
    for (p = *endp; isspace(*p); p++)
      ;
    CHECK(p == part);
    p += 4 + (*p == 's');
    mon = 12 * val;
  }

  part = strstr(p, "mon");
  if (part) {
    for (; isspace(*p); p++)
      ;
    errno = 0;
    int64_t val = strtoll(p, (char **)endp, 10);
    CHECK(!errno);
    for (p = *endp; isspace(*p); p++)
      ;
    CHECK(p == part);
    p += 3;
    if (p[0] == 't' && p[1] == 'h') {
      p += 2;
    }
    p += (*p == 's');
    mon += val;
  }

  part = strstr(p, "day");
  if (part) {
    for (; isspace(*p); p++)
      ;
    errno = 0;
    int64_t val = strtoll(p, (char **)endp, 10);
    CHECK(!errno);
    for (p = *endp; isspace(*p); p++)
      ;
    CHECK(p == part);
    p += 3;
    p += (*p == 's');
    day = val;
  }

  part = strchr(p, ':');
  if (part) {
    for (; isspace(*p); p++)
      ;
    CHECK(part - 2 == p);
    CHECK(0 == xrg_time_parse(&usec, p, endp));
    p = *endp;
  }

  CHECK(p != str);
  *endp = p;

  ret->mon = mon;
  ret->day = day;
  ret->usec = usec;
  CHECK((int64_t)ret->mon == mon);
  CHECK((int64_t)ret->day == day);
  return 0;
}

// Convert interval to X month Y day HH:MM:SS.xxxx
// Return Pointer to buf on success, NULL otherwise.
char *xrg_interval_str(xrg_interval_t interval, char *buf, int buflen) {
  if (buflen <= 0) {
    return 0;
  }

  char *p = buf;
  char *q = buf + buflen;
  if (interval.mon) {
    const char *unit = (interval.mon > 1 || interval.mon < 1) ? "mons" : "mon";
    p += snprintf(p, q - p, "%d %s", interval.mon, unit);
  }
  if (interval.day) {
    const char *unit = (interval.day > 1 || interval.day < 1) ? "days" : "day";
    p += snprintf(p, q - p, "%s%d %s", p == buf ? "" : " ", interval.day, unit);
  }
  if (interval.usec) {
    if (p < q && p != buf) {
      *p++ = ' ';
    }
    CHECKP(xrg_time_str(interval.usec, p, q - p));
  }
  if (p == buf) {
    snprintf(buf, buflen, "0 day");
  }
  return buf;
}
