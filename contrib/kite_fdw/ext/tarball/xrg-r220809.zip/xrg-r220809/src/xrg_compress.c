#include "lz4.h"
#include "xrg_int.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

int xrg_vecbuf_compress(xrg_vecbuf_t *vbuf, char *errbuf, int errbuflen) {
  if (vbuf->header.zbyte != vbuf->header.nbyte) {
    return 0; /* already compressed */
  }

  // don't bother if nbyte is less than 4kb
  if (vbuf->header.nbyte < 1024 * 4) {
    return 0;
  }

  int tmpsz = vbuf->header.nbyte * 0.7;
  char *tmp = malloc(tmpsz);
  if (!tmp) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    return -1;
  }

  int newsz = LZ4_compress_default(vbuf->data, tmp, vbuf->header.nbyte, tmpsz);
  if (!(0 < newsz && newsz < vbuf->header.nbyte)) {
    // compression failed. ignore it.
    free(tmp);
    return 0;
  }

  // compression was successful
  free(vbuf->data);
  vbuf->data = tmp;
  vbuf->datatop = newsz;
  vbuf->datamax = tmpsz;
  vbuf->header.zbyte = newsz;
  return 0;
}

int xrg_vecbuf_uncompress(xrg_vecbuf_t *vbuf, char *errbuf, int errbuflen) {
  if (vbuf->header.zbyte == vbuf->header.nbyte) {
    return 0; /* already uncompressed */
  }

  int tmpsz = vbuf->header.nbyte;
  char *tmp = malloc(tmpsz);
  if (!tmp) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    return -1;
  }

  int newsz = LZ4_decompress_safe(vbuf->data, tmp, vbuf->header.zbyte, tmpsz);
  if (newsz != vbuf->header.nbyte) {
    // decompress failed! can't ignore this!
    snprintf(errbuf, errbuflen, "%s", "LZ4_decompress_safe failed");
    free(tmp);
    return -1;
  }

  // decompress succeeded.
  free(vbuf->data);
  vbuf->data = tmp;
  vbuf->datatop = newsz;
  vbuf->datamax = tmpsz;
  vbuf->header.zbyte = newsz;
  assert(newsz == vbuf->header.nbyte);

  return 0;
}

void xrg_vector_compress(xrg_vector_t *vec) {

  if (xrg_vector_is_compressed(vec)) {
    return; /* already compressed */
  }

  // don't bother if nbyte is less than 4kb
  if (vec->header.nbyte < 1024 * 4) {
    return;
  }

  int tmpsz = vec->header.nbyte * 0.7;
  char *tmp = (char *)malloc(tmpsz);
  if (!tmp) {
    // out of memory
    return;
  }

  /* === NOTE: MUST FREE tmp BEFORE RETURNING === */

  int newsz =
      LZ4_compress_default(XRG_VECTOR_DATA(vec), tmp, vec->header.nbyte, tmpsz);
  if (!(0 < newsz && newsz < vec->header.nbyte)) {
    free(tmp);
    return;
  }

  // copy from tmp back into vec
  const char *oldflag = XRG_VECTOR_FLAG(vec);
  memcpy(XRG_VECTOR_DATA(vec), tmp, newsz);
  vec->header.zbyte = newsz;

  // shift flag into position
  memmove(XRG_VECTOR_DATA(vec) + newsz, oldflag, vec->header.nitem);

  // free tmp memory
  free(tmp);
}

xrg_vector_t *xrg_vector_uncompress(const xrg_vector_t *vec, char *errbuf,
                                    int errbuflen) {
  int nbyte = vec->header.nbyte;
  int zbyte = vec->header.zbyte;
  int nitem = vec->header.nitem;

  if (zbyte == nbyte) {
    // already compressed. just make a copy.
    int tmpsz = XRG_VECTOR_RAWSIZE(vec);
    char *tmp = malloc(tmpsz);
    if (!tmp) {
      snprintf(errbuf, errbuflen, "%s", "out of memory");
      return 0;
    }
    memcpy(tmp, vec, tmpsz);
    return (xrg_vector_t *)tmp;
  }

  int nb = sizeof(vec->header) + nbyte + vec->header.nitem;
  xrg_vector_t *ret = malloc(xrg_align(16, nb));
  if (!ret) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    return 0;
  }

  // copy header
  memcpy(&ret->header, &vec->header, sizeof(vec->header));

  // decompress vec->data into rec->data
  int newsz = LZ4_decompress_safe(XRG_VECTOR_DATA(vec), XRG_VECTOR_DATA(ret),
                                  zbyte, nbyte);
  if (newsz != nbyte) {
    // decompress failed! can't ignore this!
    snprintf(errbuf, errbuflen, "%s", "LZ4_decompress_safe failed");
    free(ret);
    return 0;
  }
  // IMPORTANT: must be set here before XRG_VECTOR_FLAG(ret) below.
  ret->header.zbyte = nbyte; /* no longer compressed */

  // copy vec->flag to ret->flag
  memcpy(XRG_VECTOR_FLAG(ret), XRG_VECTOR_FLAG(vec), nitem);

  assert(nb == XRG_VECTOR_FLAG(ret) + nitem - (char *)ret);

  // done
  return ret;
}
