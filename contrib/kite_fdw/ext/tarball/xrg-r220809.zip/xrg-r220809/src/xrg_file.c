#include "xrg_int.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int xrg_file_create(const char *fname, int nvbuf, xrg_vecbuf_t **vbuf,
                    char *errbuf, int errbuflen) {
  int fd = -1;
  int64_t dir[nvbuf];

  // create the file
  fd = open(fname, O_CREAT | O_WRONLY | O_TRUNC, 0600);
  if (fd == -1) {
    snprintf(errbuf, errbuflen, "%s", strerror(errno));
    goto bail;
  }

  // write each vector and remember its offset in dir[]
  int64_t offset = 0;
  for (int i = 0; i < nvbuf; i++) {
    dir[i] = offset;
    if (xrg_vecbuf_write(vbuf[i], fd, errbuf, errbuflen)) {
      goto bail;
    }
    offset += xrg_vecbuf_size(vbuf[i]);
  }

  // write the dir[]
  if (xrg_writefully(fd, dir, sizeof(dir), errbuf, errbuflen)) {
    goto bail;
  }

  // write footer
  xrg_footer_t footer;
  footer.nvec = nvbuf;
  memcpy(footer.magic, XRG_MAGIC, 4);
  if (xrg_writefully(fd, &footer, 8, errbuf, errbuflen)) {
    goto bail;
  }

  close(fd);
  return 0;

bail:
  if (fd >= 0) {
    close(fd);
    unlink(fname);
  }
  return -1;
}

xrg_vector_t *xrg_file_read(const char *fname, int idx, char *errbuf,
                            int errbuflen) {

  xrg_vector_t *vec = 0;
  if (xrg_file_read_ex(fname, 1, &idx, &vec, errbuf, errbuflen)) {
    return 0;
  }
  return vec;
}

int xrg_file_read_ex(const char *fname, int nidx, int *idx, xrg_vector_t **vec,
                     char *errbuf, int errbuflen) {
  int fd = -1;
  xrg_vecoff_t *vecoff = 0;
  int i;

  // zero out return values
  for (i = 0; i < nidx; i++) {
    vec[i] = 0;
  }

  // open the file
  if (-1 == (fd = open(fname, O_RDONLY))) {
    snprintf(errbuf, errbuflen, "%s", strerror(errno));
    goto bail;
  }

  // read the offsets
  if (0 == (vecoff = xrg_vecoff_from_file(fd, errbuf, errbuflen))) {
    goto bail;
  }

  // read each column
  for (int i = 0; i < nidx; i++) {
    if (!(0 <= idx[i] && idx[i] < vecoff->nvec)) {
      snprintf(errbuf, errbuflen, "index out of range");
      goto bail;
    }

    if (-1 == lseek(fd, vecoff->offset[idx[i]], SEEK_SET)) {
      snprintf(errbuf, errbuflen, "%s", strerror(errno));
      goto bail;
    }

    vec[i] = xrg_vector_read(fd, errbuf, errbuflen);
    if (!vec[i]) {
      goto bail;
    }
  }

  xrg_vecoff_release(vecoff);
  close(fd);

  return 0;

bail:
  xrg_vecoff_release(vecoff);
  if (fd >= 0) {
    close(fd);
    fd = -1;
  }
  for (int i = 0; i < nidx; i++) {
    xrg_vector_release(vec[i]);
    vec[i] = 0; // make sure caller does not get dirty ptr
  }
  return -1;
}
