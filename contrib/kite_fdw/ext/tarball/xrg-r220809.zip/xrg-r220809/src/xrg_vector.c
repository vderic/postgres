#include "xrg_int.h"
#include <assert.h>
#include <stdlib.h>

void xrg_vector_release(xrg_vector_t *v) { free(v); }

xrg_vector_t *xrg_vector_read(int fd, char *errbuf, int errbuflen) {
  xrg_vechdr_t header;
  char *tmp = 0;

  if (xrg_readfully(fd, &header, sizeof(header), errbuf, errbuflen)) {
    goto bail;
  }

  if (0 != memcmp(header.magic, XRG_MAGIC, 4)) {
    snprintf(errbuf, errbuflen, "%s", "bad magic number");
    goto bail;
  }

  // check zbyte, nbyte, nitem
  if (header.zbyte < 0) {
    snprintf(errbuf, errbuflen, "%s (%d)", "bad zbyte in header", header.zbyte);
    goto bail;
  }
  if (header.nbyte < 0) {
    snprintf(errbuf, errbuflen, "%s (%d)", "bad nbyte in header", header.nbyte);
    goto bail;
  }
  if (header.nbyte < header.zbyte) {
    snprintf(errbuf, errbuflen, "%s (%d, %d)", "bad zbyte and nbyte in header",
             header.zbyte, header.nbyte);
    goto bail;
  }
  if (header.nitem < 0) {
    snprintf(errbuf, errbuflen, "%s (%d)", "bad nitem in header", header.nitem);
    goto bail;
  }

  // check ptyp, ltyp and itemsz;
  int itemsz =
      xrg_itemsz(header.ptyp, header.ltyp, header.precision, errbuf, errbuflen);
  if (0 == itemsz) {
    goto bail;
  }
  if (header.itemsz != itemsz) {
    snprintf(errbuf, errbuflen, "%s", "bad itemsz in header");
    goto bail;
  }

  int datasz = header.zbyte;
  int flagsz = header.nitem;
  int totalsz = xrg_align(16, sizeof(header) + datasz + flagsz);

  if (0 == (tmp = malloc(totalsz))) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    goto bail;
  }

  memcpy(tmp, &header, sizeof(header));
  if (xrg_readfully(fd, tmp + sizeof(header), totalsz - sizeof(header), errbuf,
                    errbuflen)) {
    goto bail;
  }

  return (xrg_vector_t *)tmp;

bail:
  free(tmp);
  return 0;
}

xrg_vector_t *xrg_vector_from_vecbuf(const xrg_vecbuf_t *vbuf, char *errbuf,
                                     int errbuflen) {
  if (vbuf->datatop != vbuf->header.zbyte) {
    snprintf(errbuf, errbuflen, "vecbuf is corrupted");
    return 0;
  }
  if (vbuf->flagtop != vbuf->header.nitem) {
    snprintf(errbuf, errbuflen, "vecbuf is corrupted");
    return 0;
  }

  int nb = sizeof(xrg_vector_t) + vbuf->datatop + vbuf->flagtop;
  xrg_vector_t *ret = malloc(nb);
  if (!ret) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    return 0;
  }

  ret->header = vbuf->header;
  memcpy(XRG_VECTOR_DATA(ret), vbuf->data, vbuf->datatop);
  memcpy(XRG_VECTOR_FLAG(ret), vbuf->flag, vbuf->flagtop);

  return ret;
}

xrg_vector_t *xrg_vector_create_ex(int nitem, int ptyp, int ltyp, int fieldidx,
                                   int precision, int scale, char *errbuf,
                                   int errbuflen) {
  int itemsz = xrg_itemsz(ptyp, ltyp, precision, errbuf, errbuflen);
  if (itemsz == 0) {
    return 0;
  }
  if (itemsz < 0) {
    snprintf(errbuf, errbuflen,
             "xrg_vector_create only supports fixed-size types");
    return 0;
  }
  if (ltyp == XRG_LTYP_DECIMAL) {
    if (!(0 <= scale && scale < precision)) {
      snprintf(errbuf, errbuflen, "invalid scale (%d) for precision %d", scale,
               precision);
      return 0;
    }
    if (precision > 38) {
      snprintf(errbuf, errbuflen, "%s", "max precision is 38");
      return 0;
    }
  } else {
    scale = precision = 0;
  }

  int nb = xrg_align(16, sizeof(xrg_vechdr_t) + (itemsz * nitem) + nitem);
  xrg_vector_t *p = calloc(1, nb);
  if (!p) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    return 0;
  }

  int nbyte = itemsz * nitem;
  memcpy(&p->header.magic, XRG_MAGIC, 4);
  p->header.ptyp = ptyp;
  p->header.ltyp = ltyp;
  p->header.fieldidx = fieldidx;
  p->header.itemsz = itemsz;
  p->header.scale = scale;
  p->header.precision = precision;
  p->header.nbyte = nbyte;
  p->header.zbyte = nbyte;
  p->header.nitem = nitem;

  return p;
}

#define HASH_FIXED(T)                                                          \
  {                                                                            \
    const int N = vec->header.nitem;                                           \
    const T *data = (T *)XRG_VECTOR_DATA(vec);                                 \
    for (int i = 0; i < N; i++) {                                              \
      hash[i] = xrg_crc32c_mix(hash[i], &data[i], sizeof(T));                  \
    }                                                                          \
  }

static int hash_int8(const xrg_vector_t *vec, uint32_t *hash) {
  HASH_FIXED(char);
  return 0;
}

static int hash_int16(const xrg_vector_t *vec, uint32_t *hash) {
  HASH_FIXED(int16_t);
  return 0;
}
static int hash_int32(const xrg_vector_t *vec, uint32_t *hash) {
  HASH_FIXED(int32_t);
  return 0;
}
static int hash_int64(const xrg_vector_t *vec, uint32_t *hash) {
  HASH_FIXED(int64_t);
  return 0;
}
static int hash_int128(const xrg_vector_t *vec, uint32_t *hash) {
  HASH_FIXED(__int128_t);
  return 0;
}
static int hash_string(const xrg_vector_t *vec, uint32_t *hash) {
  const int N = vec->header.nitem;
  const char *data = XRG_VECTOR_DATA(vec);
  for (int i = 0; i < N; i++) {
    int len = xrg_bytea_len(data);
    hash[i] = xrg_crc32c_mix(hash[i], xrg_bytea_ptr(data), len);
    data += 4 + len;
  }
  return 0;
}

int xrg_vector_hash(const xrg_vector_t *vec, int nitem, uint32_t *hash,
                    char *errbuf, int errbuflen) {
  if (xrg_vector_is_compressed(vec)) {
    snprintf(errbuf, errbuflen, "vector is compressed");
    return -1;
  }
  if (vec->header.nitem != nitem) {
    snprintf(errbuf, errbuflen, "vector size does not match");
    return -1;
  }
  int ltyp = vec->header.ltyp;
  int ptyp = vec->header.ptyp;
  switch (XRG_LTYP_PTYP(ltyp, ptyp)) {

  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT8):
    return hash_int8(vec, hash);

  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT16):
    return hash_int16(vec, hash);

  case XRG_LTYP_PTYP(XRG_LTYP_DATE, XRG_PTYP_INT32):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT32):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_FP32):
    return hash_int32(vec, hash);

  case XRG_LTYP_PTYP(XRG_LTYP_TIME, XRG_PTYP_INT64):
  case XRG_LTYP_PTYP(XRG_LTYP_TIMESTAMP, XRG_PTYP_INT64):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT64):
  case XRG_LTYP_PTYP(XRG_LTYP_DECIMAL, XRG_PTYP_INT64):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_FP64):
    return hash_int64(vec, hash);

  case XRG_LTYP_PTYP(XRG_LTYP_DECIMAL, XRG_PTYP_INT128):
  case XRG_LTYP_PTYP(XRG_LTYP_NONE, XRG_PTYP_INT128):
  case XRG_LTYP_PTYP(XRG_LTYP_INTERVAL, XRG_PTYP_INT128):
    return hash_int128(vec, hash);

  case XRG_LTYP_PTYP(XRG_LTYP_STRING, XRG_PTYP_BYTEA):
    return hash_string(vec, hash);

  default:
    snprintf(errbuf, errbuflen, "unsupported XRG_LTYP_PTYP combination (%d,%d)",
             ltyp, ptyp);
    return -1;
  }
}
