#include "xrg_int.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void xrg_vecoff_release(xrg_vecoff_t *vecoff) { free(vecoff); }

xrg_vecoff_t *xrg_vecoff_from_file(int fd, char *errbuf, int errbuflen) {
  xrg_vecoff_t *ret = 0;
  int64_t filesz = xrg_filesize(fd, errbuf, errbuflen);
  if (filesz < 0) {
    goto bail;
  }

  xrg_footer_t footer;
  if (xrg_readfully_at(fd, filesz - sizeof(footer), (char *)&footer,
                       sizeof(footer), errbuf, errbuflen)) {
    goto bail;
  }

  if (0 != memcmp(footer.magic, XRG_MAGIC, 4)) {
    snprintf(errbuf, errbuflen, "%s", "bad magic number");
    goto bail;
  }

  int nvec = footer.nvec;
  if (nvec <= 0) {
    snprintf(errbuf, errbuflen, "%s", "invalid footer");
    goto bail;
  }

  /* alloc the xrg_vecoff_t struct using nvec */
  const char *q = (char *)&((xrg_vecoff_t *)0)->offset[nvec];
  if (!(ret = malloc(q - (char *)0))) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    goto bail;
  }
  ret->nvec = nvec;

  /* read nvec offsets into &ret->offset[0] */
  if (xrg_readfully_at(fd, filesz - sizeof(footer) - nvec * sizeof(int64_t),
                       &ret->offset[0], nvec * sizeof(int64_t), errbuf,
                       errbuflen)) {
    goto bail;
  }

  // check the offsets
  if (ret->offset[0] != 0) {
    snprintf(errbuf, errbuflen, "%s", "bad vecoff[0] in file");
    goto bail;
  }
  for (int i = 1; i < nvec; i++) {
    if (ret->offset[i] < ret->offset[i - 1]) {
      snprintf(errbuf, errbuflen, "%s", "bad vecoff in file");
      goto bail;
    }
  }

  return ret;

bail:
  free(ret);
  return 0;
}
