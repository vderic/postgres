#ifndef SOCKSTREAM_H
#define SOCKSTREAM_H

#ifdef __cplusplus
#undef EXTERN
#define EXTERN extern "C"
#else
#define EXTERN
#endif

typedef struct sockstream_t sockstream_t;

typedef struct sockbuf_t sockbuf_t;
struct sockbuf_t {
  char msgty[4];
  int msgsz;
  int bufsz;
  char *buf;
};

EXTERN void sockbuf_init(sockbuf_t *buf);
EXTERN void sockbuf_final(sockbuf_t *buf);

/* Create a sockstream, and assign sock to the sockstream. On success, caller
 * should no longer manipulate sock. The only way this call will fail is due to
 * out-of-memory error. */
EXTERN sockstream_t *sockstream_assign(int sock);

/* Destroy the sockstream. This will close the socket. */
EXTERN void sockstream_destroy(sockstream_t *ss);

/* Return the last error message. */
EXTERN const char *sockstream_errmsg(sockstream_t *ss);

/* Receive a message. Returns 0 on success, -1 otherwise. */
EXTERN int sockstream_recv(sockstream_t *ss, sockbuf_t *buf);

/* Send a message. Returns 0 on success, -1 otherwise. */
EXTERN int sockstream_send(sockstream_t *ss, const char msgty[4], int msgsz,
                           const char *msg);

#endif /* SOCKSTREAM_H */
