#include "sockstream.h"
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

void sockbuf_init(sockbuf_t *buf) { memset(buf, 0, sizeof(*buf)); }

void sockbuf_final(sockbuf_t *buf) { free(buf->buf); }

struct sockstream_t {
  int sock;
  char errmsg[200];
};

static int reterr(sockstream_t *ss, const char *m1, const char *m2) {
  snprintf(ss->errmsg, sizeof(ss->errmsg), "%s%s", m1, m2 ? m2 : "");
  return -1;
}

/* Fill buf[bufsz] with data from socket.
 * Returns 0 on success, -1 otherwise.
 */
static int sockstream_readfully(sockstream_t *ss, void *buf, int bufsz) {
  char *p = buf;
  char *const q = buf + bufsz;

  // read from stream
  while (p < q) {
    int n = recv(ss->sock, p, q - p, 0);
    if (n == 0) {
      return reterr(ss, "sockstream_readfully: unexpected end-of-stream", 0);
    }
    if (n > 0) {
      p += n;
      continue;
    }
    // retry if interrupted
    int eno = errno;
    if (eno == EINTR) {
      continue;
    }
    return reterr(ss, "sockstream_readfully: recv failed - ", strerror(eno));
  }

  assert(p == q);
  return 0;
}

/* Write bufsz bytes to socket.
 * Returns 0 on success, -1 otherwise.
 */
static int sockstream_writefully(sockstream_t *ss, const void *buf, int bufsz) {
  const char *p = buf;
  const char *const q = buf + bufsz;

  while (p < q) {
    int n = send(ss->sock, p, q - p, 0);
    if (n == 0) {
      return reterr(ss, "sockstream_writefully: unexpected end-of-stream", 0);
    }
    if (n > 0) {
      p += n;
      continue;
    }
    int eno = errno;
    if (eno == EINTR) {
      continue;
    }
    return reterr(ss, "sockstream_writefully: send failed - ", strerror(eno));
  }

  return 0;
}

sockstream_t *sockstream_assign(int sock) {
  sockstream_t *ss = malloc(sizeof(*ss));
  if (!ss) {
    return 0;
  }

  ss->sock = sock;
  ss->errmsg[0] = 0;
  return ss;
}

void sockstream_destroy(sockstream_t *ss) {
  if (ss) {
    if (ss->sock >= 0) {
      close(ss->sock);
    }
    free(ss);
  }
}

const char *sockstream_errmsg(sockstream_t *ss) { return ss->errmsg; }

int sockstream_recv(sockstream_t *ss, sockbuf_t *buf) {
  char meta[13]; // 4-byte msgty, 8-byte length, 1-byte NUL
  if (sockstream_readfully(ss, meta, 12)) {
    return -1;
  }
  meta[12] = 0; // NUL

  memcpy(buf->msgty, meta, 4);

  char *endp = 0;
  int msgsz = strtol(meta + 4, &endp, 16); // hex
  if (endp != meta + 12) {
    return reterr(ss, "sockstream_recv: bad length specifier in message", 0);
  }

  if (buf->bufsz < msgsz + 1) { // need extra byte for NUL
    int newmax = msgsz + 64;    // add some leeway
    char *tmp = malloc(newmax);
    if (!tmp) {
      return reterr(ss, "sockstream_recv: out of memory", 0);
    }
    // swap
    free(buf->buf);
    buf->buf = tmp;
    buf->bufsz = newmax;
  }

  if (sockstream_readfully(ss, buf->buf, msgsz)) {
    return -1;
  }

  assert(msgsz + 1 <= buf->bufsz);
  // add a NUL terminator just in case
  buf->buf[msgsz] = 0;
  buf->msgsz = msgsz;
  return 0;
}

int sockstream_send(sockstream_t *ss, const char msgty[4], int msgsz,
                    const char *msg) {
  if (msgsz < 0) {
    return reterr(ss, "sockstream_send: bad msgsz param", 0);
  }
  char meta[13]; // 4-byte msgty, 8-byte length, 1-byte NUL
  memcpy(meta, msgty, 4);
  sprintf(meta + 4, "%08x", msgsz);

  if (sockstream_writefully(ss, meta, 12)) {
    return -1;
  }

  if (sockstream_writefully(ss, msg, msgsz)) {
    return -1;
  }

  return 0;
}
