#include "xrg_int.h"
#include <stdlib.h>

xrg_iter_t *xrg_iter_create(int nvec, const xrg_vector_t **vec, char *errbuf,
                            int errbuflen) {
  const char *fn = "xrg_iter_create";

  xrg_iter_t *ret = 0;

  if (nvec <= 0) {
    snprintf(errbuf, errbuflen, "%s: %s", fn, "bad param");
    goto bail;
  }

  ret = calloc(1, sizeof(*ret));
  if (!ret) {
    snprintf(errbuf, errbuflen, "%s: %s", fn, "out of memory");
    goto bail;
  }

  ret->vec = calloc(nvec, sizeof(*ret->vec));
  ret->value = calloc(nvec, sizeof(*ret->value));
  ret->next_value = calloc(nvec, sizeof(*ret->next_value));
  ret->flag = calloc(nvec, sizeof(*ret->flag));
  ret->attr = calloc(nvec, sizeof(*ret->attr));
  if (!(ret->vec && ret->value && ret->flag && ret->attr)) {
    snprintf(errbuf, errbuflen, "%s: %s", fn, "out of memory");
    goto bail;
  }

  memcpy(ret->vec, vec, nvec * sizeof(*ret->vec));
  ret->nvec = nvec;
  ret->nitem = vec[0]->header.nitem;
  ret->curr = -1;

  for (int i = 0; i < nvec; i++) {
    if (xrg_vector_is_compressed(vec[i])) {
      snprintf(errbuf, errbuflen, "%s: %s", fn, "vector is compressed");
      goto bail;
    }
    ret->next_value[i] = 0;
    ret->value[i] = (void *)XRG_VECTOR_DATA(vec[i]);
    ret->flag[i] = (char *)XRG_VECTOR_FLAG(vec[i]);
    ret->attr[i].ptyp = vec[i]->header.ptyp;
    ret->attr[i].ltyp = vec[i]->header.ltyp;
    ret->attr[i].precision = vec[i]->header.precision;
    ret->attr[i].scale = vec[i]->header.scale;
    ret->attr[i].itemsz = vec[i]->header.itemsz;
  }

  return ret;

bail:
  xrg_iter_release(ret);
  return 0;
}

void xrg_iter_release(xrg_iter_t *it) {
  if (it) {
    free(it->vec);
    free(it->value);
    free(it->next_value);
    free(it->flag);
    free(it->attr);
    free(it);
  }
}

int xrg_iter_next(xrg_iter_t *it) {

again:
  const int curr = it->curr + 1;
  if (curr >= it->nitem) {
    return -1;
  }

  it->curr = curr;

  int inval = 0;
  if (0 == curr) {
    for (int i = 0, top = it->nvec; i < top; i++) {
      it->value[i] = XRG_VECTOR_DATA(it->vec[i]);
      it->next_value[i] = XRG_VECTOR_DATA(it->vec[i]);
      it->flag[i] = XRG_VECTOR_FLAG(it->vec[i]);
      inval |= (*it->flag[i]) & XRG_FLAG_INVAL;

      int itemsz = it->attr[i].itemsz;
      if (itemsz > 0) {
        it->next_value[i] = ((char *)it->next_value[i]) + itemsz;
      } else {
        it->next_value[i] = (void *)(xrg_bytea_ptr(it->next_value[i]) +
                                     xrg_bytea_len(it->next_value[i]));
      }
    }
  } else {
    // for each column:
    for (int i = 0, top = it->nvec; i < top; i++) {
      // advance the flag
      it->flag[i] += 1;
      inval |= (*it->flag[i]) & XRG_FLAG_INVAL;

      it->value[i] = it->next_value[i];

      // advance the value
      int itemsz = it->attr[i].itemsz;
      if (itemsz > 0) {
        it->next_value[i] = ((char *)it->next_value[i]) + itemsz;
      } else {
        it->next_value[i] = (void *)(xrg_bytea_ptr(it->next_value[i]) +
                                     xrg_bytea_len(it->next_value[i]));
      }
    }
  }

  // this row is invalid?
  if (inval) {
    goto again;
  }

  return 0;
}
