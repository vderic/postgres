#include "version.i.c"
#include "xrg_int.h"

const char *xrg_version() {
  static char version[100] = {0};
  if (version[0]) {
    return version;
  }

  snprintf(version, sizeof(version), "%s %s (git-hash %s) (%s)", XRG_MAGIC,
           XRG_BUILD, XRG_BUILD_HASH, XRG_BUILD_TYPE);
  return version;
}
