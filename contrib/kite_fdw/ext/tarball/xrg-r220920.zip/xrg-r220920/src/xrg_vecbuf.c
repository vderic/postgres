#include "xrg_int.h"
#include <assert.h>
#include <immintrin.h>
#include <stdio.h>
#include <stdlib.h>

#define INLINE inline __attribute__((always_inline))

#define xstr(s) STRINGIFY(s)
#define STRINGIFY(s) #s

const char *xrg_ptyp_to_string(int ptyp) {
  switch (ptyp) {
// clang-format off
#define CASE(x) case x: return #x
    // clang-format on
    CASE(XRG_PTYP_INT8);
    CASE(XRG_PTYP_INT16);
    CASE(XRG_PTYP_INT32);
    CASE(XRG_PTYP_INT64);
    CASE(XRG_PTYP_INT128);
    CASE(XRG_PTYP_FP32);
    CASE(XRG_PTYP_FP64);
    CASE(XRG_PTYP_BYTEA);
  default:
    CASE(XRG_PTYP_UNKNOWN);
#undef CASE
  }
}

const char *xrg_ltyp_to_string(int ltyp) {
  switch (ltyp) {
// clang-format off
#define CASE(x) case x: return #x
    // clang-format on
    CASE(XRG_LTYP_NONE);
    CASE(XRG_LTYP_STRING);
    CASE(XRG_LTYP_DECIMAL);
    CASE(XRG_LTYP_INTERVAL);
    CASE(XRG_LTYP_TIME);
    CASE(XRG_LTYP_DATE);
    CASE(XRG_LTYP_TIMESTAMP);
  default:
    CASE(XRG_LTYP_UNKNOWN);
#undef CASE
  }
}

xrg_vecbuf_t *xrg_vecbuf_create(int ptyp, int ltyp, int fieldidx, int scale,
                                int precision, char *errbuf, int errbuflen) {
  int itemsz = xrg_itemsz(ptyp, ltyp, precision, errbuf, errbuflen);
  if (itemsz == 0) {
    return 0;
  }
  if (ltyp == XRG_LTYP_DECIMAL) {
    if (!(0 <= scale && scale < precision)) {
      snprintf(errbuf, errbuflen, "invalid scale (%d) for precision %d", scale,
               precision);
      return 0;
    }
    if (precision > 38) {
      // DECIMAL: Formula: unscaledValue * 10^(-scale)
      // int32: max precision is 9.
      // int64: max precision is 18.
      // int128: max precision is 38 (max supported at the moment).
      // int256: max precision is 76.
      snprintf(errbuf, errbuflen, "%s", "max precision is 38");
      return 0;
    }
  } else {
    scale = precision = 0;
  }
  xrg_vecbuf_t *p = calloc(1, sizeof(*p));
  if (!p) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    return 0;
  }
  memcpy(&p->header.magic, XRG_MAGIC, 4);
  p->header.ptyp = ptyp;
  p->header.ltyp = ltyp;
  p->header.fieldidx = fieldidx;
  p->header.itemsz = itemsz;
  p->header.scale = scale;
  p->header.precision = precision;
  return p;
}

void xrg_vecbuf_release(xrg_vecbuf_t *vbuf) {
  if (vbuf) {
    free(vbuf->data);
    free(vbuf->flag);
    free(vbuf);
  }
}

/* Expand vbuf->data by sz bytes */
static int expand_data(xrg_vecbuf_t *vbuf, int sz, char *errbuf,
                       int errbuflen) {
  char *tmp = realloc(vbuf->data, sz);
  if (!tmp) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    return -1;
  }
  vbuf->data = tmp;
  vbuf->datamax = sz;
  return 0;
}

/* Expand vbuf->flag by sz bytes */
static int expand_flag(xrg_vecbuf_t *vbuf, int sz, char *errbuf,
                       int errbuflen) {
  char *tmp = realloc(vbuf->flag, sz);
  if (!tmp) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    return -1;
  }
  vbuf->flag = tmp;
  vbuf->flagmax = sz;
  return 0;
}

/* Make sure that vbuf->data can accomodate 'additional' bytes */
static INLINE int ensure_data(xrg_vecbuf_t *vbuf, int addition, char *errbuf,
                              int errbuflen) {
  return (vbuf->datatop + addition > vbuf->datamax)
             ? expand_data(vbuf, vbuf->datatop + addition + 200, errbuf,
                           errbuflen)
             : 0;
}

/* Make sure that vbuf->flag can accomodate 'additional' bytes */
static INLINE int ensure_flag(xrg_vecbuf_t *vbuf, int addition, char *errbuf,
                              int errbuflen) {
  return (vbuf->flagtop + addition > vbuf->flagmax)
             ? expand_flag(vbuf, vbuf->flagtop + addition + 100, errbuf,
                           errbuflen)
             : 0;
}

/* Count the number nulls and invals in flag[n] */
static void count_flags(const char *flag, int n, int *ret_nnull,
                        int *ret_ninval) {
  int nnull = 0;
  int ninval = 0;

  // count 8-bytes at a time
  for (int i = 0; i < n / 8; i++, flag += 8) {
    uint64_t v = *(uint64_t *)flag;
    uint64_t null_flag = v & (0x0101010101010101);
    uint64_t inval_flag = v & (0x0202020202020202);
    nnull += _mm_popcnt_u64(null_flag); // count #bits set
    ninval += _mm_popcnt_u64(inval_flag);
  }

  {
    // count the remaining bytes
    uint64_t v = 0;
    switch (n & 7) {
    case 7:
      v = (v << 8) | *(unsigned char *)flag++;
    // fallthru
    case 6:
      v = (v << 8) | *(unsigned char *)flag++;
    // fallthru
    case 5:
      v = (v << 8) | *(unsigned char *)flag++;
    // fallthru
    case 4:
      v = (v << 8) | *(unsigned char *)flag++;
    // fallthru
    case 3:
      v = (v << 8) | *(unsigned char *)flag++;
    // fallthru
    case 2:
      v = (v << 8) | *(unsigned char *)flag++;
    // fallthru
    case 1:
      v = (v << 8) | *(unsigned char *)flag++;
      // fallthru
    }
    uint64_t null_flag = v & (0x0101010101010101);
    uint64_t inval_flag = v & (0x0202020202020202);
    nnull += _mm_popcnt_u64(null_flag);
    ninval += _mm_popcnt_u64(inval_flag);
  }

  *ret_nnull = nnull;
  *ret_ninval = ninval;
}

/* Check vbuf for append operation */
static INLINE int append_check(xrg_vecbuf_t *vbuf, int itemsz, char *errbuf,
                               int errbuflen) {
  if (vbuf->header.itemsz != itemsz) {
    snprintf(errbuf, errbuflen, "%s", "itemsz mismatch");
    return -1;
  }
  if (xrg_vecbuf_is_compressed(vbuf)) {
    snprintf(errbuf, errbuflen, "%s", "buffer is compressed");
    return -1;
  }
  return 0;
}

/* Append nitem of fixed size to vbuf */
static INLINE int append_fixed(xrg_vecbuf_t *vbuf, int nitem, int itemsz,
                               const void *ptr, const char *flag, char *errbuf,
                               int errbuflen) {
  int nb = itemsz * nitem;
  if (ensure_data(vbuf, nb, errbuf, errbuflen)) {
    return -1;
  }
  if (ensure_flag(vbuf, nitem, errbuf, errbuflen)) {
    return -1;
  }
  memcpy(&vbuf->data[vbuf->datatop], ptr, nb);
  memcpy(&vbuf->flag[vbuf->flagtop], flag, nitem);
  vbuf->datatop += nb;
  vbuf->flagtop += nitem;
  vbuf->header.nitem += nitem;
  vbuf->header.nbyte += nb;
  vbuf->header.zbyte = vbuf->header.nbyte;

  int nnull, ninval;
  count_flags(flag, nitem, &nnull, &ninval);
  vbuf->header.nnull += nnull;
  vbuf->header.ninval += ninval;
  return 0;
}

#define DO_APPEND_FIXED(vbuf, nitem, ptr, flag, errbuf, errbuflen)             \
  {                                                                            \
    int itemsz = sizeof(*ptr);                                                 \
    if (append_check(vbuf, itemsz, errbuf, errbuflen)) {                       \
      return -1;                                                               \
    }                                                                          \
    if (append_fixed(vbuf, nitem, itemsz, ptr, flag, errbuf, errbuflen)) {     \
      return -1;                                                               \
    }                                                                          \
    return 0;                                                                  \
  }

int xrg_vecbuf_append_int8(xrg_vecbuf_t *vbuf, int nitem, const int8_t *ptr,
                           const char *flag, char *errbuf, int errbuflen) {
  DO_APPEND_FIXED(vbuf, nitem, ptr, flag, errbuf, errbuflen);
}

int xrg_vecbuf_append_int16(xrg_vecbuf_t *vbuf, int nitem, const int16_t *ptr,
                            const char *flag, char *errbuf, int errbuflen) {
  DO_APPEND_FIXED(vbuf, nitem, ptr, flag, errbuf, errbuflen);
}

int xrg_vecbuf_append_int32(xrg_vecbuf_t *vbuf, int nitem, const int32_t *ptr,
                            const char *flag, char *errbuf, int errbuflen) {
  DO_APPEND_FIXED(vbuf, nitem, ptr, flag, errbuf, errbuflen);
}

int xrg_vecbuf_append_int64(xrg_vecbuf_t *vbuf, int nitem, const int64_t *ptr,
                            const char *flag, char *errbuf, int errbuflen) {
  DO_APPEND_FIXED(vbuf, nitem, ptr, flag, errbuf, errbuflen);
}

int xrg_vecbuf_append_int128(xrg_vecbuf_t *vbuf, int nitem,
                             const __int128_t *ptr, const char *flag,
                             char *errbuf, int errbuflen) {
  DO_APPEND_FIXED(vbuf, nitem, ptr, flag, errbuf, errbuflen);
}

int xrg_vecbuf_append_fp32(xrg_vecbuf_t *vbuf, int nitem, const float *ptr,
                           const char *flag, char *errbuf, int errbuflen) {
  DO_APPEND_FIXED(vbuf, nitem, ptr, flag, errbuf, errbuflen);
}

int xrg_vecbuf_append_fp64(xrg_vecbuf_t *vbuf, int nitem, const double *ptr,
                           const char *flag, char *errbuf, int errbuflen) {
  DO_APPEND_FIXED(vbuf, nitem, ptr, flag, errbuf, errbuflen);
}

/* Append nitem of variable size to vbuf */
int xrg_vecbuf_append_bytea(xrg_vecbuf_t *vbuf, int nitem, char *const *ptr,
                            const int *len, char *flag, char *errbuf,
                            int errbuflen) {
  if (append_check(vbuf, -1, errbuf, errbuflen))
    return -1;

  // compute total #bytes needed in vbuf->data[]
  int nb = 0;
  for (int i = 0; i < nitem; i++) {
    int32_t sz = len[i];
    if (sz < 0 || sz > (1 << 30)) {
      snprintf(errbuf, errbuflen, "%s", "invalid string length");
      return -1;
    }
    nb += 4 + sz;
  }
  if (vbuf->datamax - vbuf->datatop < nb &&
      expand_data(vbuf, vbuf->datatop + nb + 200, errbuf, errbuflen)) {
    return -1;
  }
  if (vbuf->flagmax - vbuf->flagtop < nitem &&
      expand_flag(vbuf, vbuf->flagtop + nitem + 100, errbuf, errbuflen)) {
    return -1;
  }

  // copy the data
  char *p = &vbuf->data[vbuf->datatop];
  char *q = p + nb;
  (void)q; /* deflect 'unused variable' warning */
  for (int i = 0; i < nitem; i++) {
    p = xrg_bytea_encode(p, ptr[i], len[i]);
  }
  assert(p == q);

  // copy the flag
  memcpy(&vbuf->flag[vbuf->flagtop], flag, nitem);

  vbuf->datatop += nb;
  vbuf->flagtop += nitem;
  vbuf->header.nitem += nitem;
  vbuf->header.nbyte += nb;
  vbuf->header.zbyte = vbuf->header.nbyte;

  int nnull, ninval;
  count_flags(flag, nitem, &nnull, &ninval);
  vbuf->header.nnull += nnull;
  vbuf->header.ninval += ninval;
  return 0;
}

int xrg_vecbuf_extract_bytea(xrg_vecbuf_t *vbuf, int nitem, char **ptr,
                             int *len, char *errbuf, int errbuflen) {
  if (nitem != vbuf->header.nitem) {
    snprintf(errbuf, errbuflen, "%s", "bad nitem in param");
    return -1;
  }
  if (xrg_vecbuf_is_compressed(vbuf)) {
    snprintf(errbuf, errbuflen, "%s", "buffer is compressed");
    return -1;
  }
  if (vbuf->header.itemsz != -1) {
    snprintf(errbuf, errbuflen, "%s", "items in buffer are not bytea's");
    return -1;
  }

  char *p = vbuf->data;
  char *const q = p + vbuf->datatop;
  int i;
  for (i = 0; i < nitem && p < q; i++) {
    len[i] = xrg_bytea_len(p);
    ptr[i] = (char *)xrg_bytea_ptr(p);
    p = (char *)ptr[i] + len[i];
  }

  if (i != nitem || p != q) {
    snprintf(errbuf, errbuflen, "%s", "buffer is corrupted");
    return -1;
  }

  return 0;
}

int xrg_vecbuf_write(xrg_vecbuf_t *vbuf, int fd, char *errbuf, int errbuflen) {
  int total = 0;

  // write the header
  int nb = sizeof(vbuf->header);
  if (xrg_writefully(fd, &vbuf->header, nb, errbuf, errbuflen)) {
    return -1;
  }
  total += nb;

  // write the data[]
  assert(vbuf->datatop == vbuf->header.zbyte);
  nb = vbuf->datatop;
  if (xrg_writefully(fd, vbuf->data, nb, errbuf, errbuflen)) {
    return -1;
  }
  total += nb;

  // write the flag[]
  assert(vbuf->flagtop == vbuf->header.nitem);
  nb = vbuf->flagtop;
  if (xrg_writefully(fd, vbuf->flag, nb, errbuf, errbuflen)) {
    return -1;
  }
  total += nb;

  // pad to 16-byte boundary
  char pad[16] = {0};
  int padsz = xrg_align(16, total) - total;
  if (xrg_writefully(fd, pad, padsz, errbuf, errbuflen)) {
    return -1;
  }
  total += padsz;

  return 0;
}

xrg_vecbuf_t *xrg_vecbuf_read(int fd, char *errbuf, int errbuflen) {
  xrg_vecbuf_t *vbuf = 0;
  char *tmp = 0;

  vbuf = calloc(1, sizeof(*vbuf));
  if (!vbuf) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    goto bail;
  }

  if (xrg_readfully(fd, &vbuf->header, sizeof(vbuf->header), errbuf,
                    errbuflen)) {
    goto bail;
  }

  if (0 != memcmp(vbuf->header.magic, XRG_MAGIC, 4)) {
    snprintf(errbuf, errbuflen, "%s", "bad magic number");
    goto bail;
  }

  // check zbyte, nbyte, nitem
  if (vbuf->header.zbyte < 0) {
    snprintf(errbuf, errbuflen, "%s (%d)", "bad zbyte in header",
             vbuf->header.zbyte);
    goto bail;
  }
  if (vbuf->header.nbyte < 0) {
    snprintf(errbuf, errbuflen, "%s (%d)", "bad nbyte in header",
             vbuf->header.nbyte);
    goto bail;
  }
  if (vbuf->header.nbyte < vbuf->header.zbyte) {
    snprintf(errbuf, errbuflen, "%s (%d, %d)", "bad zbyte and nbyte in header",
             vbuf->header.zbyte, vbuf->header.nbyte);
    goto bail;
  }
  if (vbuf->header.nitem < 0) {
    snprintf(errbuf, errbuflen, "%s (%d)", "bad nitem in header",
             vbuf->header.nitem);
    goto bail;
  }

  // check ptyp, ltyp and itemsz;
  int itemsz = xrg_itemsz(vbuf->header.ptyp, vbuf->header.ltyp,
                          vbuf->header.precision, errbuf, errbuflen);
  if (0 == itemsz) {
    goto bail;
  }
  if (vbuf->header.itemsz != itemsz) {
    snprintf(errbuf, errbuflen, "%s", "bad itemsz in header");
    goto bail;
  }

  int datasz = vbuf->header.zbyte;
  int flagsz = vbuf->header.nitem;
  int totalsz = xrg_align(16, datasz + flagsz);

  if (0 == (tmp = malloc(totalsz))) {
    snprintf(errbuf, errbuflen, "%s", "out of memory");
    goto bail;
  }
  if (xrg_readfully(fd, tmp, totalsz, errbuf, errbuflen)) {
    goto bail;
  }

  if (expand_data(vbuf, datasz, errbuf, errbuflen)) {
    goto bail;
  }
  if (expand_flag(vbuf, flagsz, errbuf, errbuflen)) {
    goto bail;
  }

  memcpy(vbuf->data, tmp, datasz);
  vbuf->datatop = datasz;

  memcpy(vbuf->flag, tmp + datasz, flagsz);
  vbuf->flagtop = flagsz;

  free(tmp);
  assert(xrg_vecbuf_is_valid(vbuf));
  return vbuf;

bail:
  xrg_vecbuf_release(vbuf);
  free(tmp);
  return 0;
}

int xrg_vecbuf_is_valid(const xrg_vecbuf_t *vbuf) {
  char errbuf[100];
  const xrg_vechdr_t *h = &vbuf->header;

  // check magic
  if (0 != memcmp(h->magic, XRG_MAGIC, 4)) {
    return 0;
  }

  // check valid ptyp/ltyp
  int itemsz =
      xrg_itemsz(h->ptyp, h->ltyp, h->precision, errbuf, sizeof(errbuf));
  if (itemsz == 0) {
    return 0;
  }

  // for decimal type, check scale and precisions
  if (h->ltyp == XRG_LTYP_DECIMAL) {
    if (!(0 <= h->scale && h->scale < h->precision)) {
      return 0;
    }
  } else if (h->scale || h->precision) {
    // non-decimal type, make sure these are zeros
    return 0;
  }

  // check some invarients
  if (!(h->fieldidx >= 0)) {
    return 0;
  }
  if (!(h->zbyte <= h->nbyte)) {
    return 0;
  }
  if (!(h->nnull <= h->nitem)) {
    return 0;
  }
  if (h->unused1 || h->unused2) {
    return 0;
  }

  // check the buffers
  if (!(0 <= vbuf->datatop && vbuf->datatop <= vbuf->datamax)) {
    return 0;
  }
  if (!(0 <= vbuf->flagtop && vbuf->flagtop <= vbuf->flagmax)) {
    return 0;
  }
  if (!(vbuf->flagtop == h->nitem)) {
    return 0;
  }
  if (h->nbyte == h->zbyte) {
    // for uncompressed buffer ...
    if (itemsz > 0) {
      // check fixed size items filled vbuf->data[] fully
      if (h->nitem * itemsz != vbuf->datatop) {
        return 0;
      }
    } else {
      // scan var size items
      const char *p = vbuf->data;
      char *const q = vbuf->data + vbuf->datatop;
      for (int i = 0; i < h->nitem && p < q; i++) {
        uint32_t len = xrg_bytea_len(p);
        if (len > (1 << 30)) {
          return 0;
        }
        p = xrg_bytea_ptr(p) + len;
      }
      if (p != q) { // filled fully?
        return 0;
      }
    }
  }

  // count the nulls and invals
  int nnull, ninval;
  count_flags(vbuf->flag, h->nitem, &nnull, &ninval);
  if (nnull != h->nnull) {
    return 0;
  }
  if (ninval != h->ninval) {
    return 0;
  }

  return 1;
}
