#define _LARGEFILE64_SOURCE
#define _POSIX_C_SOURCE 200809L
#include "harness.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Test xrg_file_read() */
int main() {

#ifdef NDEBUG
  fprintf(stderr, "warning: running in NON-DEBUG...\n");
#endif

  char errbuf[100];
  const int errbuflen = sizeof(errbuf);
  xrg_vecbuf_t *vbuf[8];
  vbuf[0] = xrg_vecbuf_create(XRG_PTYP_INT8, XRG_LTYP_NONE, 0, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[0]);
  vbuf[1] = xrg_vecbuf_create(XRG_PTYP_INT16, XRG_LTYP_NONE, 1, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[1]);
  vbuf[2] = xrg_vecbuf_create(XRG_PTYP_INT32, XRG_LTYP_NONE, 2, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[2]);
  vbuf[3] = xrg_vecbuf_create(XRG_PTYP_INT64, XRG_LTYP_NONE, 3, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[3]);
  vbuf[4] = xrg_vecbuf_create(XRG_PTYP_INT128, XRG_LTYP_NONE, 4, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[4]);
  vbuf[5] = xrg_vecbuf_create(XRG_PTYP_FP32, XRG_LTYP_NONE, 5, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[5]);
  vbuf[6] = xrg_vecbuf_create(XRG_PTYP_FP64, XRG_LTYP_NONE, 6, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[6]);
  vbuf[7] = xrg_vecbuf_create(XRG_PTYP_BYTEA, XRG_LTYP_STRING, 7, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[7]);

  for (int j = 0; j < 1000; j++) {
    char flag[10] = {0};
    int8_t i8[10];
    int16_t i16[10];
    int32_t i32[10];
    int64_t i64[10];
    __int128_t i128[10];
    float fp32[10];
    double fp64[10];
    char str[10][10];
    char *sptr[10];
    int slen[10];

    for (int i = 0; i < 10; i++) {
      i8[i] = i;
      i16[i] = i;
      i32[i] = i;
      i64[i] = i;
      i128[i] = i;
      fp32[i] = i;
      fp64[i] = i;
      sprintf(str[i], "%d%d%d%d", i, i, i, i);
      sptr[i] = str[i];
      slen[i] = strlen(sptr[i]);
    }

    CHECK(0 ==
          xrg_vecbuf_append_int8(vbuf[0], 10, i8, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int16(vbuf[1], 10, i16, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int32(vbuf[2], 10, i32, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int64(vbuf[3], 10, i64, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_int128(vbuf[4], 10, i128, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_fp32(vbuf[5], 10, fp32, flag, errbuf, errbuflen));
    CHECK(0 ==
          xrg_vecbuf_append_fp64(vbuf[6], 10, fp64, flag, errbuf, errbuflen));
    CHECK(0 == xrg_vecbuf_append_bytea(vbuf[7], 10, sptr, slen, flag, errbuf,
                                       errbuflen));
  }

  for (int i = 0; i < 8; i++) {
    CHECK(0 == xrg_vecbuf_compress(vbuf[i], errbuf, errbuflen));
    CHECK(xrg_vecbuf_is_compressed(vbuf[i]));
  }

  /* write to file */
  const char *OUTFILE = "test6.xrg";
  CHECK(0 == xrg_file_create(OUTFILE, 8, vbuf, errbuf, errbuflen));

  /* read from file */
  for (int i = 0; i < 8; i++) {
    CHECK(0 == xrg_vecbuf_uncompress(vbuf[i], errbuf, errbuflen));

    xrg_vector_t *yy = xrg_file_read(OUTFILE, i, errbuf, errbuflen);
    CHECK(yy);

    xrg_vector_t *xx = xrg_vector_uncompress(yy, errbuf, errbuflen);
    CHECK(xx);
    xrg_vector_release(yy);
    yy = 0;

    // check the content of xx is the same as vbuf[i]
    CHECK(0 == memcmp(&xx->header, &vbuf[i]->header, sizeof(xx->header)));
    CHECK(xx->header.zbyte == vbuf[i]->datatop);

    /*
    for (int j = 0; j < xx->header.zbyte; j++) {
      printf("j = %d, x = %02x, y = %02x\n", j, XRG_VECTOR_DATA(xx)[j],
             vbuf[i]->data[j]);
    }
    */

    CHECK(0 == memcmp(XRG_VECTOR_DATA(xx), vbuf[i]->data, xx->header.zbyte));
    CHECK(0 == memcmp(XRG_VECTOR_FLAG(xx), vbuf[i]->flag, xx->header.nitem));
    xrg_vector_release(xx);
  }

  CHECK(0 == xrg_file_read(OUTFILE, 8, errbuf, errbuflen));

  /* clean up */
  for (int i = 0; i < 8; i++) {
    xrg_vecbuf_release(vbuf[i]);
  }
  return 0;
}
