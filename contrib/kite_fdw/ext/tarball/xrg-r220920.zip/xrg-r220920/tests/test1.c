#define _LARGEFILE64_SOURCE
#define _POSIX_C_SOURCE 200809L
#include "harness.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Test vecbuf. Read / write empty vecbuf */
int main() {

#ifdef NDEBUG
  fprintf(stderr, "warning: running in NON-DEBUG...\n");
#endif

  char errbuf[100];
  const int errbuflen = sizeof(errbuf);
  xrg_vecbuf_t *vbuf[8];
  vbuf[0] = xrg_vecbuf_create(XRG_PTYP_INT8, XRG_LTYP_NONE, 0, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[0]);
  vbuf[1] = xrg_vecbuf_create(XRG_PTYP_INT16, XRG_LTYP_NONE, 1, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[1]);
  vbuf[2] = xrg_vecbuf_create(XRG_PTYP_INT32, XRG_LTYP_NONE, 2, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[2]);
  vbuf[3] = xrg_vecbuf_create(XRG_PTYP_INT64, XRG_LTYP_NONE, 3, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[3]);
  vbuf[4] = xrg_vecbuf_create(XRG_PTYP_INT128, XRG_LTYP_NONE, 4, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[4]);
  vbuf[5] = xrg_vecbuf_create(XRG_PTYP_FP32, XRG_LTYP_NONE, 5, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[5]);
  vbuf[6] = xrg_vecbuf_create(XRG_PTYP_FP64, XRG_LTYP_NONE, 6, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[6]);
  vbuf[7] = xrg_vecbuf_create(XRG_PTYP_BYTEA, XRG_LTYP_STRING, 7, 0, 0, errbuf,
                              errbuflen);
  CHECK(vbuf[7]);

  for (int i = 0; i < 8; i++) {
    CHECK(xrg_vecbuf_is_valid(vbuf[i]));
  }

  for (int i = 0; i < 8; i++) {
    CHECK(0 == xrg_vecbuf_compress(vbuf[i], errbuf, errbuflen));
    // the vecbufs are empty. calling compress is a NOP.
    // so, assert that buffer is NOT compressed.
    CHECK(!xrg_vecbuf_is_compressed(vbuf[i]));
  }

  /* write to file */
  const char *OUTFILE = "test1.xrg";
  CHECK(0 == xrg_file_create(OUTFILE, 8, vbuf, errbuf, errbuflen));

  /* read from file */
  int fd = open(OUTFILE, O_RDONLY, 0);
  CHECK(fd >= 0);
  xrg_vecoff_t *vecoff = xrg_vecoff_from_file(fd, errbuf, errbuflen);
  CHECK(vecoff);
  CHECK(vecoff->nvec == 8);

  xrg_vecbuf_t *xx[8];
  for (int i = 0; i < 8; i++) {
    CHECK(-1 != lseek64(fd, vecoff->offset[i], SEEK_SET));
    xx[i] = xrg_vecbuf_read(fd, errbuf, errbuflen);
    CHECK(xx[i]);
    if (i != 7) {
      CHECK(vecoff->offset[i + 1] == lseek64(fd, 0, SEEK_CUR));
    }

    // check the content of xx[i] is the same as vbuf[i]
    CHECK(0 == memcmp(&xx[i]->header, &vbuf[i]->header, sizeof(xx[i]->header)));
    CHECK(xx[i]->datatop == vbuf[i]->datatop);
    CHECK(xx[i]->flagtop == vbuf[i]->flagtop);
    CHECK(0 == memcmp(xx[i]->data, vbuf[i]->data, xx[i]->datatop));
    CHECK(0 == memcmp(xx[i]->flag, vbuf[i]->flag, xx[i]->flagtop));
  }
  xrg_vecoff_release(vecoff);

  close(fd);

  /* clean up */
  for (int i = 0; i < 8; i++) {
    xrg_vecbuf_release(vbuf[i]);
    xrg_vecbuf_release(xx[i]);
  }
  return 0;
}
